// const mongoose = require('mongoose');

// const dbURL = 'mongodb://localhost:27017/adminpanel';

// mongoose.connect(dbURL, {
//   useNewUrlParser: true,
//   useUnifiedTopology: true,
// });

// const db = mongoose.connection;

// db.on('error', console.error.bind(console, 'MongoDB connection error:'));
// db.once('open', () => {
//   console.log('Connected to the database.');
// });

const mysql = require('mysql2/promise');

const pool = mysql.createPool({

  host: 'localhost',
  user: 'root',
  password: 'Osiz@123', 
  database: 'mariadb',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  connectionLimit: 5,
});

async function connectToDatabase() {
  try {
    const connection = await pool.getConnection();
    console.log('Connected to database!');
    connection.release();
  } catch (err) {
    console.error('Error connecting to database:', err.message);
  }
}

// Calling the function to connect to the database
connectToDatabase();


module.exports = pool;


