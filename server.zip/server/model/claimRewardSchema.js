const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'users',
        require: true,
    }, 
    balance: {
        type:Number,
         default: 0, 
       },
   
    annualinterest:{
        type:Number,
    }
   
});

const Claim = mongoose.model('Claims', userSchema);

module.exports = Claim;