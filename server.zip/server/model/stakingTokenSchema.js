const mongoose = require('mongoose');

const StakingHistory=new mongoose.Schema({
   
    PlanName:{
        type:String
    },
     PlanAmount:{
        type: Number
      },    
    AmountInterest:{
        type:Number
    },  
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'users',
        require: true,
    },
    createdAt:{
        type:Date,
        default:Date.now()
    },
})

module.exports=planmodel=mongoose.model('stackhistory',StakingHistory)