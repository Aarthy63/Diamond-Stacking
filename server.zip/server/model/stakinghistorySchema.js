const mongoose = require('mongoose');

const StakingHistory = new mongoose.Schema({
    amountinterest:{
        type: Number
      },
    planname:{
        type:String
    },
   planamount:{
       type:Number
   }, 
   planmonth:{
    type: String,
  },
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'users',
        require: true,
    },
    createdAt:{
        type:Date,
        default:Date.now()
    },
    status:{
        type: String,
         default: false
    },
})

module.exports=planmodel=mongoose.model('Buylist',StakingHistory)