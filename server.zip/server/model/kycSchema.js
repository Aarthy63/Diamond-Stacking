const mongoose = require('mongoose');

const kycSchema = new mongoose.Schema({
 selectProof: {
  type: String,
 required: true,
 },
  aadharNumber: {
    type: String,
    required: true,
  },
  
  aadharFront: {
    type: String,
    required: true,
  },
  aadharBack: {
    type: String,
    required: true,
  },
  selfieImg: {
    type: String,
    required: true,
  },
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Users',
    required: true,
  },
  kycVerifiy: {
    type: Boolean,
    default: false,
  },
  waitingStatus: {
    type: Boolean,
    default: true,
  },
  
});

const VerifyKyc = mongoose.model('KycVerify', kycSchema)
module.exports = VerifyKyc