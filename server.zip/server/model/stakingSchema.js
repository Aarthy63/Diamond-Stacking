const mongoose = require('mongoose');

const StakingHistory=new mongoose.Schema({
    planname:{
        type:String
    },
    planmonth:{
      type: Number
    },
    planamount:{
        type:Number
    },
    planinterest:{
        type:Number
    },  
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'users',
        require: true,
    },
    createdAt:{
        type:Date,
        default:Date.now()
    },
})

module.exports=planmodel=mongoose.model('StakingList',StakingHistory)