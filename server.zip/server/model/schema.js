const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  firstName: {
    type: String,
    required: true
  },
  lastName: {
    type: String,
    required: true
  },
  email: {
    type: String,
    required: true
  },
  username: {
    type: String,
    required: true
  },
    password: {
    type: String,
    required: true
  },
  otp: {
    code: {
        type: String,
        required: true,
    },
    expiration: {
        type: Date,
        required: true,
    },
},
twoFactorAuth: {
  type: Boolean,
  default: false
},
updatedAt: {
    type: Date,
},
verified: {
    type: Boolean,
    default: false,
},
temp_secret: {
  type: Object
},
secret: {
  type: Object,
},
// kycstatus:{
//   type:Boolean,
//   default:false
// },
// selectproof:{
//   type: String
// },
// pannumber: {
//   type: String
// },
// frontSideImg: {
//   type:String
// },
// backSideImg: {
//   type:String
// },
// kycSelfieImg: {
//   type:String
// },

createdAt:{
  type:Date,
  default:Date.now()
},
kyc: {
  accountNo: String,
  proofType: String,
  username: String,
  email: String,
  mobile: String,
  address: String,
  
  upload: {
    frontProof: {
      type: String,
    },
    backProof: {
      type: String,
    },
    frontSideStatus: {
      type: String,
      default: "pending",
    },
    backSideStatus: {
      type: String,
      default: "pending",
    },
  },
  isApproved: {
    type: Boolean,
    default: false,
  },

  adminComment: { type: String, default: "" },
  repliedAt: { type: Date, default: "" },
  userLastUpdate: { type: Date, default: "" },
  userUpdateStatus: { type: Boolean, default: false },
},
 
},
 {collection: 'users'});

const User = mongoose.model('User', userSchema);
module.exports = User;