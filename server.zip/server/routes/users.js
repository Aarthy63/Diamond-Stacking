
const express = require('express');
const router = express.Router();
const userController = require('../controller/userController')

router.get("/", userController.get );
 router.post("/register", userController.post);
router.post("/create", userController.createUser)

router.get("/fetchuser", userController.fetchuser);
router.put("/update/:id", userController.updateById);
router.post("/login", userController.login);
router.get("/getSingle", userController.getSingle)
router.get("/fetchuser/:id", userController.fetchuserById );
router.delete("/deleteuser/:id", userController.deleteuserById);
router.post("/forgetPassword" , userController.forgetPassword)

router.post("/verifyOtp", userController.verifyOtp)
router.post("/setNewPassword", userController.setNewPassword)
router.post("/forgetpasswordverifyOtp", userController.forgetPasswordverifyOtp)
router.post("/loginverifyOtp", userController.loginverifyOtp)
router.post("/handleTwoFactorAuthentication", userController.handleTwoFactorAuthentication)
router.post("/verifyTwoFactorAuthentication", userController.verifyTwoFactorAuthentication)
router.post("/getTwoFactorAuthentication", userController.getTwoFactorAuthentication)
router.post("/disableTwoFactorAuthentication", userController.disableTwoFactorAuthentication)
// router.post("/submitkyc", userController.handlekyc)
router.post("/kyc/:id", userController.kyc);
router.post('/changePassword', userController.changePassword);
router.post('/Userdetails', userController.getUserDetails);
router.post('/Imageupload', userController.updateUserDetails);

router.post('/getData', userController.faqFetchingData)
 

router.post("/URLUpdates",userController.updateSiteSettingsURL );
router.post("/getURLData",userController.handleGetSiteSettingURL );

router.post('/buyplan',userController.handlebuyplan)
router.post('/stakeplan',userController.handlestake)
router.get('/planlist',userController.handleplan )
router.get('/gethistory', userController.handlebuyer)
router.post('/claimReward', userController.claimRewardamount)

module.exports = router;




