// import React, { Component, Suspense } from 'react';
// import logo from './logo.svg';
// import './App.css';
// import 'bootstrap/dist/css/bootstrap.min.css';
// import '../src/style.scss';
// import {
//    BrowserRouter, Navigate, Route, Routes
// } from 'react-router-dom';
// import Login from './views/Login/Login';
// import Home from './views/Home/Home';
// import Innerpages from './views/Innerpages/Innerpages';
// import Proposal from './views/Proposal/Proposal';
// import NewProposal from './views/NewProposal/NewProposal';
// import ProposalDetails from './views/ProposalDetails/ProposalDetails';
// import Settings from './views/Settings/Settings';
// import Voting from './views/Voting/Voting';
// import Members from './views/Members/Members';
// import Terms from './views/Terms/Terms';
// import Privacy from './views/Privacy/Privacy';
// import Faq from './views/Faq/Faq';
// import Register from './views/Register/Register';
// import ForgotPassword from './views/ForgotPassword/ForgotPassword';
// import KYC from './views/KYC/KYC';
// import BuyPlan from './views/BuyPlan/BuyPlan';
// import PlanList from './views/PlanList/PlanList';
// import Stake from './views/Stake/Stake';
// import Unstake from './views/Unstake/Unstake';
// import StakeOne from './views/StakeOne/StakeOne';
// import About from './views/About/About';
// import StakingDetails from './views/StakingDetails/StakingDetails';
// import ChangePassword from './views/ChangePassword/ChangePassword';
// import Pagenotfound from './components/Pagenotfound/PageNotFound';
// // import VerifyEmail from './views/VerifyEmail/VerifyEmail';
// import ForgotPasswordOtp from './views/ForgotPassword/ForgotPasswordOtp'
// import RegisterOtp from './views/Register/RegisterOtp';
// import LoginOtp from './views/Login/LoginOtp'
// import FASecurityPage from './views/SecurityPage/FASecurityPage';
// import Getaccounts from './views/getaccounts/Getaccounts';
// import Profile from './views/Support/Profile'
// // import NewBuyPlan from './views/NewBuyPlan/NewBuyPlan';
// import Dashboard from './views/Dashboard/Dashboard'

// const App = (props) => {
//    const PrivatRouter = ({ component }) => {
//       const privatelogin = localStorage.getItem('userId')
//       if (privatelogin) {
//         return component
//       } else {
//         return <Navigate to='/Login' />
//       }
//     }
   
//    return (
//       <React.Fragment>
//          <BrowserRouter>
//             <Routes history={props.history}>
//                {/* <Route path = '/Login' element={<Login />}/> */}
//               <Route path='/' element={<Home />} />
//               {/* <Route path='*' element={<Innerpages />} /> */}
//                {/* <Route path= '/*' element={<Pagenotfound />}/> */}
//               <Route path='/proposal' element={<Proposal />} />
//               <Route path='/newproposal' element={<NewProposal />} />
//               <Route path='/proposaldetails' element={<ProposalDetails />} />
//               {/* <Route path='/settings' element={<Settings />} />
//               <Route path='/voting' element={<Voting />} />
//               <Route path='/members' element={<Members />} /> */}
//               <Route path='/dashboard' element={<Dashboard/>}/>
//             {/* <Route path='/Dashboard' element={<PrivatRouter component={< Dashboard />} />} /> */}
//               <Route path='/terms' element={<Terms />} />
//               <Route path='/privacy' element={<Privacy />} />
//               <Route path='/faq' element={<Faq />} />
//               <Route path='/login' element={<Login />} />
//             <Route path='/LoginOtp' element={<LoginOtp />} /> 
//               <Route path='/ChangePassword' element={<ChangePassword />} />
//               {/* <Route path='/ChangePassword' element={<PrivatRouter component={< ChangePassword />} />} /> */}
              
//               <Route path='/register' element={<Register />} />
//               {/* <Route path='/register' element={<PrivatRouter component={< Register />} />} /> */}
//               <Route path='/RegisterOtp' element={<RegisterOtp />} />
//               <Route path='/FASecurityPage' element={<FASecurityPage />} />
//               {/* <Route path='/FASecurityPage' element={<PrivatRouter component={< FASecurityPage />} />} /> */}
//               {/* <Route path='VerifyEmail' element={<VerifyEmail />} /> */}
//               <Route path='/Forgotpassword' element={<ForgotPassword />} />
//               {/* <Route path='/Forgotpassword' element={<PrivatRouter component={< ForgotPassword />} />} /> */}
//               <Route path='/kyc' element={<KYC />} />
//               {/* <Route path='/kyc' element={<PrivatRouter component={< KYC />} />} /> */}
//               {/* <Route path='/buyplan/:id' element={<BuyPlan />} /> */}
//               {/* <Route path='/BuyPlan/:id' element={<BuyPlan />} /> */}
//               <Route path='/BuyPlan/:id' element={<PrivatRouter component={< BuyPlan />} />} />
//               <Route path='/planlist' element={<PrivatRouter component={< PlanList />} />} />
//               {/* <Route path='/planlist' element={<PlanList />} /> */}
//               <Route path='/stake' element={<Stake />} />
//               <Route path='/unstake' element={<Unstake />} />
//               <Route path='/about' element={<About />} />
//               {/* <Route path='/StakingDetails' element={<StakingDetails />} /> */}
//               <Route path='/StakingDetails' element={<PrivatRouter component={< StakingDetails />} />} />
//               <Route path='/ForgotPasswordOtp' element={<PrivatRouter component={< ForgotPasswordOtp />} />} />
//                <Route path='/Getaccounts' element={<PrivatRouter component={< Getaccounts />} />} />
//               {/* <Route path= '/Getaccounts' element={<Getaccounts />}/> */}
//               {/* <Route path='/Profile' element={<Profile />}/> */}
//                      <Route path='/Profile' element={<PrivatRouter component={< Profile />} />} />
//               {/* <Route path='/NewBuyPlan' element={<NewBuyPlan />}/> */}
//             </Routes>
//          </BrowserRouter>
//       </React.Fragment>
//    );
// }

// export default App;
import React, { Component, Suspense } from 'react';
import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../src/style.scss';
import {
   BrowserRouter, Navigate, Route, Routes
} from 'react-router-dom';
import Login from './views/Login/Login';
import 'react-toastify/dist/ReactToastify.css';
import Home from './views/Home/Home';
import Innerpages from './views/Innerpages/Innerpages';
import Proposal from './views/Proposal/Proposal';
import NewProposal from './views/NewProposal/NewProposal';
import ProposalDetails from './views/ProposalDetails/ProposalDetails';
import Settings from './views/Settings/Settings';
import Voting from './views/Voting/Voting';
import Members from './views/Members/Members';
import Terms from './views/Terms/Terms';
import Privacy from './views/Privacy/Privacy';
import login from './views/Login/Login';
import Faq from './views/Faq/Faq';
import Register from './views/Register/Register';
import ForgotPassword from './views/ForgotPassword/ForgotPassword';
import KYC from './views/KYC/KYC';
import BuyPlan from './views/BuyPlan/BuyPlan';
import PlanList from './views/PlanList/PlanList';
import Stake from './views/Stake/Stake';
import Unstake from './views/Unstake/Unstake';
import StakeOne from './views/StakeOne/StakeOne';
import About from './views/About/About';
import StakingDetails from './views/StakingDetails/StakingDetails';
import ChangePassword from './views/ChangePassword/ChangePassword';
import ForgotPasswordOtp from './views/ForgotPassword/ForgotPasswordOtp'
import RegisterOtp from './views/Register/RegisterOtp';
import LoginOtp from './views/Login/LoginOtp'
import FASecurityPage from './views/SecurityPage/FASecurityPage';
import Getaccounts from './views/getaccounts/Getaccounts';
import Dashboard from './views/Dashboard/Dashboard'
import Profile from './views/Support/Profile'
import PrivateRoute from './views/PrivateRouter/PrivateRouter';
 


const App = (props) => {
 
   
   return (
      <React.Fragment>
         <BrowserRouter>
            <Routes history={props.history}>              
              <Route path = '/login' element={<Login />}/>
              <Route path='/' element={<Home />} />
              <Route path='*' element={<Innerpages />} /> 
              <Route path='/proposal' element={<Proposal />} />
              <Route path='/newproposal' element={<NewProposal />} />
              <Route path='/proposaldetails' element={<ProposalDetails />} />
              <Route path='/settings' element={<Settings />} />
              <Route path='/voting' element={<Voting />} />
              <Route path='/members' element={<Members />} /> 
              <Route path='/terms' element={<Terms />} />
              <Route path='/privacy' element={<Privacy />} />
              <Route path='/faq' element={<Faq />} />
              <Route path='/LoginOtp' element={<LoginOtp />} />
              <Route path="/ChangePassword" element={<ChangePassword />} />
              <Route path='/register' element={<Register />} />
             <Route path='/RegisterOtp' element={<RegisterOtp />} />
             <Route path="/FASecurtiyPage" element={<FASecurityPage />} /> 
              {/* <Route path="/FASecurityPage" element={
                        <PrivateRoute>
                            <FASecurityPage />
                         </PrivateRoute>}/> */}
               <Route path='/Forgotpassword' element= {< ForgotPassword />} />             
              {/* <Route path='/BuyPlan/:id' element={<BuyPlan />} />
              <Route path='/planlist' element={<PlanList />} /> */}
              <Route path='/about' element={<About />} />
              {/* <Route path='/StakingDetails' element={< StakingDetails />} />  */}
              <Route path='/ForgotPasswordOtp' element={< ForgotPasswordOtp />} />
              <Route path='/Getaccounts' element={< Getaccounts />} />
              {/* <Route path="/KYC" element={
                     <PrivateRoute>
                          <KYC />
                    </PrivateRoute>}/> */}
              {/* <Route path="/StackingDetails" element={
                      <PrivateRoute>
                        <StakingDetails />
                      </PrivateRoute>}/> */}
             {/* <Route path="/BuyPlan/:id" element={
                       <PrivateRoute>
                         <BuyPlan />
                      </PrivateRoute>}/> */}
             {/* <Route path="/Planlist" element={
                       <PrivateRoute>
                         <PlanList />
                     </PrivateRoute>}/> */}
                     <Route path='/PlanList' element={<PlanList/>}/>
                     <Route path='/BuyPlan/:id' element={<BuyPlan/>}/>
                     <Route path='/unstake/:id' element={<Unstake/>}/>
                     <Route path='/KYC' element={<KYC/>}/>
                     <Route path='/StakingDetails' element={<StakingDetails/>}/>
                     <Route path='/Unstake/:id' element={<Unstake/>}/>
              <Route path='/profile' element={<Profile />}/>
            </Routes>
         </BrowserRouter>
      </React.Fragment>
   );
}

export default App;