// import React, { Fragment, useEffect, useState } from "react";
// import { Container, Row, Col, Modal, ModalHeader, ModalBody, UncontrolledDropdown, DropdownToggle, DropdownMenu, DropdownItem,
// 	Collapse,
// 	Navbar,
// 	NavbarToggler,
// 	NavbarBrand,
// 	Nav,
// 	NavItem, NavLink
// } from 'reactstrap';
// import { useNavigate } from "react-router-dom";
// import stkUnstkImg1 from '../../assets/images/stk-unstk-img1.svg';
// import swpIcon2 from '../../assets/images/swp-icon2.svg';
// import { useClaimRewardMutation } from "../redux/api";
// import { ToastContainer, toast } from 'react-toastify'
// import "react-toastify/dist/ReactToastify.css";
// import ReactDOM from "react-dom";
// import {
// 	BrowserRouter, Navigate, useParams, Route, Routes, Link,
//  } from 'react-router-dom';

 
//  const Unstake = (props) => {
//     const {id}= useParams()
//     const navigate = useNavigate();
//   const [claimRewardMutation] = useClaimRewardMutation();
//   const [annualInterest, setAnnualInterest] = useState(0);  // Assuming you can set the annualInterest from somewhere

//   const onSubmit = async () => {
//     try {
//      const userId=localStorage.getItem("userId")
//       const response = await claimRewardMutation({ id: userId, annualInterest });
//       console.log(response);
   
//     } catch (error) {
//       console.error("An error occurred:", error.message);
//     }
//   };

//     return (
//       <Fragment>

//         <div className="DbCntMain">
//             <div className="BluBg107 SwapMainSec BluBgLight">
//                 <div className="SwpHdd mb-4">
//                     <h4>Unstake</h4>
//                 </div>
//                 <form className=" " onSubmit={(onSubmit)}>
//                 <div className="row ">
//                     <div className="col-xl-4 col-lg-6 mb-4">
//                         <div className="StkUnStkBox">
//                             <div className="StkUnStkHddSec text-center mb-4">
//                                 <div className="StkUnStkHddImg mb-3">
//                                     <img src={stkUnstkImg1} alt="" className="img-fluid" />
//                                 </div>
//                                 <div className="StkUnStkHdd">
//                                     <h4>20.578941 <span className="ml-2">OSIZ</span></h4>
//                                 </div>
//                             </div>
//                             <div className="StkBlnDtlsFlx">
//                                 <div className="StkBlnDtls1">
//                                     <p>SHIMS Balance</p>
//                                 </div>
//                                 <div className="StkBlnDtls2 text-right">
//                                     <p>40.00154</p>
//                                 </div>
//                             </div>
//                             <div className="StkBlnDtlsFlx">
//                                 <div className="StkBlnDtls1">
//                                     <p>APY</p>
//                                 </div>
//                                 <div className="StkBlnDtls2 text-right">
//                                     <p>4.74%</p>
//                                 </div>
//                             </div>
//                             <div className="StkClmBtnSec text-center mt-4">
//                                 <button className="btn StkClmBtn">Claim Reward</button>
//                             </div>
//                         </div>
//                     </div>
//                 </div>
//                 </form>
//             </div>
//         </div>
		
//       </Fragment>
//     );
    
// }

// export default Unstake;
import React, { Fragment, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useForm } from "react-hook-form";
import { ToastContainer, toast } from 'react-toastify';
import "react-toastify/dist/ReactToastify.css";
import { yupResolver } from "@hookform/resolvers/yup";
import * as Yup from "yup";
import { useClaimRewardMutation } from "../redux/api";
import "react-toastify/dist/ReactToastify.css";

const RewardClaim = () => {
  const navigate = useNavigate();
  const { id } = useParams();
 
  const [claimReward] = useClaimRewardMutation();
  const validationSchema = Yup.object().shape({
    // Add any validation for the reward claiming form fields
  });

  const { register, handleSubmit, formState: { errors } } = useForm({
    resolver: yupResolver(validationSchema),
    mode: 'all',
  });

  const onSubmit = async (data) => {
       try {
      const usersId = localStorage.getItem("userId");
      const response = await claimReward({ usersId: id, ...data });
     console.log(response);
      if (response.error) {
        toast.error(response.error.data.message);
      } else {
        toast.success(response.data.message, {
          position: toast.POSITION.TOP_CENTER,
          autoClose: false,
        });
        setTimeout(() => {
          navigate('/StakingDetails');
        }, 4000);
      }
    } catch (error) {
      console.error("An error occurred:", error.message);
    }
  };

  return (
    <Fragment>
      <div className="DbCntMain">
        <div className="BluBg107 SwapMainSec BluBgLight">
          <div className="SwpHdd mb-4">
            <h4 style={{ textAlign: 'center' }}>Claim Reward</h4>
          </div>
          <form onSubmit={handleSubmit(onSubmit)}>
            {/* Add your reward claiming form fields here */}
            <div className="form-group">
              <label htmlFor="rewardAmount">Reward Amount:</label>
              <input
                type="text"
                id="rewardAmount"
                {...register('rewardAmount')}
                className={`form-control ${errors.rewardAmount ? 'is-invalid' : ''}`}
              />
              <div className="invalid-feedback">
                {errors.rewardAmount?.message}
              </div>
            </div>
            <div className="form-group">
              <button type="submit" className="btn BtnPrimry w-100 mt-4">
                <span>Claim Reward</span>
              </button>
            </div>
          </form>
          <ToastContainer />
        </div>
      </div>
    </Fragment>
  );
};

export default RewardClaim;
