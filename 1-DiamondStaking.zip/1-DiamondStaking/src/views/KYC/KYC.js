// import React, { Fragment, useState } from "react";
// import Header from "../../components/Header/Header";
// import Footer from "../../components/Footer/Footer";
// import termsBanner from '../../assets/images/termsBanner.png';
// import logo from '../../assets/images/logo.png';
// import aadar from '../../assets/images/aadar.png';
// import kyc from '../../assets/images/blu-bg-light.png';
// import Pencil from "../../assets/images/ext-link-icon.svg";
// import { useKycsubmitDataMutation } from "../redux/api";
// import * as yup from "yup"
// import { ToastContainer, toast } from 'react-toastify';
// import { useForm } from 'react-hook-form';
// import { yupResolver } from '@hookform/resolvers/yup';
// import Swal from 'sweetalert2';
// import { useNavigate } from "react-router-dom";


// const schema = yup.object().shape({
//     selectproof: yup.string()
//         .required("please select the proof")
//         .trim(),
//     pannumber: yup.string()
//         .matches(/^[a-zA-Z 0-9 ]*$/, "Enter a valid PanNumber")
//         .required("Enter a valid PanNumber")
//         .min(3, "Name must be at least 3 characters")
//         .max(20, "Name should not exceed 20 characters")
//         .trim(),
//     frontSideImg: yup
//         .mixed()
//         .test("fileRequired", "Profile Pic is Required", (value) => {
//             return value && value.length > 0;
//         })
//         .test("fileSize", "File size is too large", (value) => {
//             return value && value[0] && value[0].size <= 1024000;
//         })
//         .test("fileFormat", "Invalid file format", (value) => {
//             return (
//                 value &&
//                 value.length > 0 &&
//                 ["image/jpeg", "image/png"].includes(value[0].type)
//             );
//         }),
//     backSideImg: yup
//         .mixed()
//         .test("fileRequired", "Profile Pic is Required", (value) => {
//             return value && value.length > 0;
//         })
//         .test("fileSize", "File size is too large", (value) => {
//             return value && value[0] && value[0].size <= 1024000;
//         })
//         .test("fileFormat", "Invalid file format", (value) => {
//             return (
//                 value &&
//                 value.length > 0 &&
//                 ["image/jpeg", "image/png"].includes(value[0].type)
//             );
//         }),
//     kycSelfieImg: yup
//         .mixed()
//         .test("fileRequired", "Profile Pic is Required", (value) => {
//             return value && value.length > 0;
//         })
//         .test("fileSize", "File size is too large", (value) => {
//             return value && value[0] && value[0].size <= 1024000;
//         })
//         .test("fileFormat", "Invalid file format", (value) => {
//             return (
//                 value &&
//                 value.length > 0 &&
//                 ["image/jpeg", "image/png"].includes(value[0].type)
//             );
//         }),
// });



// const KYC = (props) => {
//     const navigate = useNavigate();
//     const [selectproof , setSelectProof] = useState(null);
//     const [ pannumber, setPannumber] = useState(null);
//     const [formData, setFormData] = useState({});
//     const [submitKyc] = useKycsubmitDataMutation()
//     const [frontSideImg, setFrontSideImg] = useState(null);
//     const [backSideImg, setBackSideImg] = useState(null);
//     const [kycSelfieImg, setKycSelfieImg] = useState(null);

//     const handleFileChange = (e) => {
//         // const file = event.target.files[0];
//         // if (file) {
//         //     setImgSrc(file);
//         // }
//         // console.log(e.target.files);
//         setFrontSideImg(e.target.files[0])
//       };
//       const handleFileBackChange = (e)=> {
//         setBackSideImg (e.target.files[0])
//       }
//       const handleFileselfieChange = (e)=> {
//         setKycSelfieImg (e.target.files[0])
//       }


//     const {
//         handleSubmit, formState, register, reset } = useForm({
//             resolver: yupResolver(schema),
//             mode: 'all'
//         });

//     const onSubmit = async (data) => {
//         console.log(data);

//         try {
//             const loginuserid = localStorage.getItem('verifyUserId');             const selectProof = selectproof;
//             const Pannumber = pannumber;
//             const frontimage = frontSideImg;
//             const backimage = backSideImg;
//             const selfie = kycSelfieImg;


//             const formData = new FormData();
//             formData.append("selectProof", data.selectproof);
//             formData.append("panNumber",data. pannumber);
//             formData.append("id", loginuserid);
//             formData.append("frontSideImg", frontimage);
//             formData.append("backSideImg", backimage );
//             formData.append("kycSelfieImg", selfie );


//             let response = await submitKyc(formData);
//             if (response.data) {
//                 Swal.fire({
//                     position: "top-end",
//                     icon: "success",
//                     title: `Kyc Sumbitted successfully..`,
//                     showConfirmButton: false,
//                     timer: 2500
//                 });
//             }
//             setTimeout (()=>{
//                 navigate('/planlist')
//             })
//             reset();

//             console.log(response.data.message);

//         } catch (error) {
//             console.error('Error submitting KYC details:', error);
//         }
//     };

//     return (
//         <Fragment>
//             <Header />
//             <div className="Main-section cmsSec" style={{ paddingTop: '80px' }}>
//                 <div className="container container-1200">
//                     <form className="w-100" onSubmit={handleSubmit(onSubmit)}>
//                     <div className="row justify-content-center">
//                         <div className="col-lg-8">
//                             <div className="LgnPg">
//                                 <img src={logo} className="img-fluid d-block mx-auto" />
//                                 <h3>KYC</h3>
//                                 <div className="form-group">
//                                     <label>Select Proof</label>
//                                     <select className="form-control"   {...register("selectproof")}>
//                                         <option>Licence</option>
//                                         <option>Aadar Card</option>
//                                         <option>Pan Card</option>
//                                         <p className="text-danger"> {formState.errors.firstName?.message} </p>
//                                     </select>
//                                 </div>
//                                 <div className="form-group">
//                                     <label>PAN Number</label>
//                                     <input type="text" className="form-control" {...register("pannumber")}
//                                     />
//                                     <p className="text-danger"> {formState.errors.pannumber?.message} </p>
//                                 </div>
//                                 <div className="form-group">
//                                     <label>Front Side ID Proof</label>
//                                     <div className="UpldDvPf">

//                                         {/* <img src={kyc} className="img-fluid " /> */}
//                                         <input
//                                             type="file"
//                                             id="frontSideImg"
//                                             {...register("frontSideImg")}
//                                             style={{
//                                                 position: "absolute",
//                                                 width: "100%",
//                                             }}
//                                             // role="button"
//                                             onChange={handleFileChange}
//                                         />

//                                         <label for="back-id">
//                                             <div class="choosefile-grid">
//                                                 <div class="kyc-previewbox">
//                                                     {/* <img src={kyc } /> */}
//                                                 </div>
//                                             </div>
//                                         </label>
//                                         <p className="text-danger"> {formState.errors.frontSideImg?.message} </p>
//                                     </div>

//                                 </div>
//                                 <div className="form-group">
//                                     <label>Back Side ID Proof</label>
//                                     <div className="UpldDvPf">

//                                         {/* <img src={kyc} className="img-fluid " style={{ marginTop: '-42px' }} /> */}
//                                         <input
//                                             type="file"
//                                             id="backSideImg"
//                                             {...register("backSideImg")}
//                                             style={{
//                                                 position: "absolute",
//                                                 width: "100%",
//                                             }}
//                                             role="button"
//                                             onChange={handleFileBackChange}
//                                         />

//                                         <label for="back-id">
//                                             <div class="choosefile-grid">
//                                                 <div class="kyc-previewbox">
//                                                     {/* <img src={backSideImg} /> */}
//                                                 </div>
//                                             </div>
//                                         </label>
//                                         <p className="text-danger"> {formState.errors.backSideImg?.message} </p>
//                                     </div>

//                                 </div>
//                                 <div className="form-group">
//                                     <label>KYC Selfie With ID Proof</label>
//                                     <div className="UpldDvPf">

//                                         {/* <img src={kyc} className="img-fluid " style={{ marginTop: '-42px' }} /> */}
//                                         <input
//                                             type="file"
//                                             id="kycSelfieImg"
//                                             {...register("kycSelfieImg")}
//                                             style={{
//                                                 position: "absolute",
//                                                 width: "100%",
//                                             }}
//                                             role="button"
//                                             onChange={handleFileselfieChange}
//                                         />

//                                         <label for="back-id">
//                                             <div class="choosefile-grid">
//                                                 <div class="kyc-previewbox">
//                                                     {/* <img src={kycSelfieImg} /> */}
//                                                 </div>
//                                             </div>
//                                         </label>
//                                         <p className="text-danger"> {formState.errors.kycSelfieImg?.message} </p>
//                                     </div>
//                                 </div>
//                                 <button type="submit" className="btn LGn-btn">Submit</button>
//                             </div>
//                         </div>
//                     </div>
//                     </form>
//                 </div>
//             </div>
//             <Footer />
//         </Fragment>
//     );

// }

// export default KYC;

// import React, { Fragment, useState } from "react";
// import Header from "../../components/Header/Header";
// import Footer from "../../components/Footer/Footer";
// import termsBanner from '../../assets/images/termsBanner.png';
// import logo from '../../assets/images/logo.png';
// import aadar from '../../assets/images/aadar.png';
// import kyc from '../../assets/images/blu-bg-light.png';
// import Pencil from "../../assets/images/ext-link-icon.svg";
// import { useKycsubmitDataMutation } from "../redux/api";
// import * as yup from "yup"
// import { ToastContainer, toast } from 'react-toastify';
// import { useForm } from 'react-hook-form';
// import { yupResolver } from '@hookform/resolvers/yup';
// import Swal from 'sweetalert2';
// import { useNavigate } from "react-router-dom";


// const schema = yup.object().shape({
//     selectproof: yup.string()
//         .required("please select the proof")
//         .trim(),
//     pannumber: yup.string()
//         .matches(/^[a-zA-Z 0-9 ]*$/, "Enter a valid PanNumber")
//         .required("Enter a valid PanNumber")
//         .min(3, "Name must be at least 3 characters")
//         .max(20, "Name should not exceed 20 characters")
//         .trim(),
//     frontSideImg: yup
//         .mixed()
//         .test("fileRequired", "Profile Pic is Required", (value) => {
//             return value && value.length > 0;
//         })
//         .test("fileSize", "File size is too large", (value) => {
//             return value && value[0] && value[0].size <= 1024000;
//         })
//         .test("fileFormat", "Invalid file format", (value) => {
//             return (
//                 value &&
//                 value.length > 0 &&
//                 ["image/jpeg", "image/png"].includes(value[0].type)
//             );
//         }),
//     backSideImg: yup
//         .mixed()
//         .test("fileRequired", "Profile Pic is Required", (value) => {
//             return value && value.length > 0;
//         })
//         .test("fileSize", "File size is too large", (value) => {
//             return value && value[0] && value[0].size <= 1024000;
//         })
//         .test("fileFormat", "Invalid file format", (value) => {
//             return (
//                 value &&
//                 value.length > 0 &&
//                 ["image/jpeg", "image/png"].includes(value[0].type)
//             );
//         }),
//     kycSelfieImg: yup
//         .mixed()
//         .test("fileRequired", "Profile Pic is Required", (value) => {
//             return value && value.length > 0;
//         })
//         .test("fileSize", "File size is too large", (value) => {
//             return value && value[0] && value[0].size <= 1024000;
//         })
//         .test("fileFormat", "Invalid file format", (value) => {
//             return (
//                 value &&
//                 value.length > 0 &&
//                 ["image/jpeg", "image/png"].includes(value[0].type)
//             );
//         }),
// });



// const KYC = (props) => {
//     const navigate = useNavigate();
//     const [selectproof , setSelectProof] = useState(null);
//     const [ pannumber, setPannumber] = useState(null);
//     const [formData, setFormData] = useState({});
//     const [submitKyc] = useKycsubmitDataMutation()
//     const [frontSideImg, setFrontSideImg] = useState(null);
//     const [backSideImg, setBackSideImg] = useState(null);
//     const [kycSelfieImg, setKycSelfieImg] = useState(null);

//     const handleFileChange = (e) => {
//         // const file = event.target.files[0];
//         // if (file) {
//         //     setImgSrc(file);
//         // }
//         // console.log(e.target.files);
//         setFrontSideImg(e.target.files[0])
//       };
//       const handleFileBackChange = (e)=> {
//         setBackSideImg (e.target.files[0])
//       }
//       const handleFileselfieChange = (e)=> {
//         setKycSelfieImg (e.target.files[0])
//       }


//     const {
//         handleSubmit, formState, register, reset } = useForm({
//             resolver: yupResolver(schema),
//             mode: 'all'
//         });

//     const onSubmit = async (data) => {
//         console.log(data);

//         try {
//             const loginuserid = localStorage.getItem('verifyUserId');             const selectProof = selectproof;
//             const Pannumber = pannumber;
//             const frontimage = frontSideImg;
//             const backimage = backSideImg;
//             const selfie = kycSelfieImg;


//             const formData = new FormData();
//             formData.append("selectProof", data.selectproof);
//             formData.append("panNumber",data. pannumber);
//             formData.append("id", loginuserid);
//             formData.append("frontSideImg", frontimage);
//             formData.append("backSideImg", backimage );
//             formData.append("kycSelfieImg", selfie );


//             let response = await submitKyc(formData);
//             if (response.data) {
//                 Swal.fire({
//                     position: "top-end",
//                     icon: "success",
//                     title: `Kyc Sumbitted successfully..`,
//                     showConfirmButton: false,
//                     timer: 2500
//                 });
//             }
//             setTimeout (()=>{
//                 navigate('/planlist')
//             },3000)
//             reset();

//             console.log(response.data.message);

//         } catch (error) {
//             console.error('Error submitting KYC details:', error);
//         }
//     };

//     return (
//         <Fragment>
//             <Header />
//             <div className="Main-section cmsSec" style={{ paddingTop: '80px' }}>
//                 <div className="container container-1200">
//                     <form className="w-100" onSubmit={handleSubmit(onSubmit)}>
//                     <div className="row justify-content-center">
//                         <div className="col-lg-8">
//                             <div className="LgnPg">
//                                 <img src={logo} className="img-fluid d-block mx-auto" />
//                                 <h3>KYC</h3>
//                                 <div className="form-group">
//                                     <label>Select Proof</label>
//                                     <select className="form-control"   {...register("selectproof")}>
//                                         <option>Licence</option>
//                                         <option>Aadar Card</option>
//                                         <option>Pan Card</option>
//                                         <p className="text-danger"> {formState.errors.firstName?.message} </p>
//                                     </select>
//                                 </div>
//                                 <div className="form-group">
//                                     <label>PAN Number</label>
//                                     <input type="text" className="form-control" {...register("pannumber")}
//                                     />
//                                     <p className="text-danger"> {formState.errors.pannumber?.message} </p>
//                                 </div>
//                                 <div className="form-group">
//                                     <label>Front Side ID Proof</label>
//                                     <div className="UpldDvPf">

//                                         {/* <img src={kyc} className="img-fluid " /> */}
//                                         <input
//                                             type="file"
//                                             id="frontSideImg"
//                                             {...register("frontSideImg")}
//                                             style={{
//                                                 position: "absolute",
//                                                 width: "100%",
//                                             }}
//                                             // role="button"
//                                             onChange={handleFileChange}
//                                         />

//                                         <label for="back-id">
//                                             <div class="choosefile-grid">
//                                                 <div class="kyc-previewbox">
//                                                     {/* <img src={kyc } /> */}
//                                                 </div>
//                                             </div>
//                                         </label>
//                                         <p className="text-danger"> {formState.errors.frontSideImg?.message} </p>
//                                     </div>

//                                 </div>
//                                 <div className="form-group">
//                                     <label>Back Side ID Proof</label>
//                                     <div className="UpldDvPf">

//                                         {/* <img src={kyc} className="img-fluid " style={{ marginTop: '-42px' }} /> */}
//                                         <input
//                                             type="file"
//                                             id="backSideImg"
//                                             {...register("backSideImg")}
//                                             style={{
//                                                 position: "absolute",
//                                                 width: "100%",
//                                             }}
//                                             role="button"
//                                             onChange={handleFileBackChange}
//                                         />

//                                         <label for="back-id">
//                                             <div class="choosefile-grid">
//                                                 <div class="kyc-previewbox">
//                                                     {/* <img src={backSideImg} /> */}
//                                                 </div>
//                                             </div>
//                                         </label>
//                                         <p className="text-danger"> {formState.errors.backSideImg?.message} </p>
//                                     </div>

//                                 </div>
//                                 <div className="form-group">
//                                     <label>KYC Selfie With ID Proof</label>
//                                     <div className="UpldDvPf">

//                                         {/* <img src={kyc} className="img-fluid " style={{ marginTop: '-42px' }} /> */}
//                                         <input
//                                             type="file"
//                                             id="kycSelfieImg"
//                                             {...register("kycSelfieImg")}
//                                             style={{
//                                                 position: "absolute",
//                                                 width: "100%",
//                                             }}
//                                             role="button"
//                                             onChange={handleFileselfieChange}
//                                         />

//                                         <label for="back-id">
//                                             <div class="choosefile-grid">
//                                                 <div class="kyc-previewbox">
//                                                     {/* <img src={kycSelfieImg} /> */}
//                                                 </div>
//                                             </div>
//                                         </label>
//                                         <p className="text-danger"> {formState.errors.kycSelfieImg?.message} </p>
//                                     </div>
//                                 </div>
//                                 <button type="submit" className="btn LGn-btn">Submit</button>
//                             </div>
//                         </div>
//                     </div>
//                     </form>
//                 </div>
//             </div>
//             <Footer />
//         </Fragment>
//     );

// }

// export default KYC;

import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
// import Header from "../Components/Header";
import {
  useGetSingleUserQuery,
  useKycDetailsMutation,
} from "../redux/api";
import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from "reactstrap";
import Swal from "sweetalert2";
import { useNavigate } from "react-router-dom";

const createSchema = (frontSideStatus, backSideStatus) => {
  const baseSchema = yup.object().shape({
    username: yup.string().required("Username is required"),
    email: yup.string().email("Invalid email").required("Email is required"),
    mobile: yup
      .string()
      .required("Phone number is required")
      .matches(/^[0-9]\d{9}$/, "Invalid Number")

      .trim(),
    accountNo: yup
      .string()
      .required("Account number is required")
      .matches(/^[0-9]*$/, "Characters Not Allowed")
      .min(15, "Account should be in 15 digits")
      .trim(),
    proofType: yup.string().required("Select Proof is required"),
    address: yup
      .string()
      .required("Address is required")
      .matches(/[A-Za-z]+/, "Address should contain Alphabets"),
  });

  if (frontSideStatus === "Approved") {
    baseSchema.fields.frontProof = yup.mixed().notRequired();
  } else {
    baseSchema.fields.frontProof = yup
      .mixed()
      .test("fileRequired", "Profile Pic is Required", (value) => {
        return value && value.length > 0;
      })
      .test("fileSize", "File size is too large", (value) => {
        return value && value[0] && value[0].size <= 1024000;
      })
      .test("fileFormat", "Invalid file format", (value) => {
        return (
          value &&
          value.length > 0 &&
          ["image/jpeg", "image/png"].includes(value[0].type)
        );
      });
  }

  if (backSideStatus === "Approved") {
    baseSchema.fields.backProof = yup.mixed().notRequired();
  } else {
    baseSchema.fields.backProof = yup
      .mixed()
      .test("fileRequired", "Profile Pic is Required", (value) => {
        return value && value.length > 0;
      })
      .test("fileSize", "File size is too large", (value) => {
        return value && value[0] && value[0].size <= 1024000;
      })
      .test("fileFormat", "Invalid file format", (value) => {
        return (
          value &&
          value.length > 0 &&
          ["image/jpeg", "image/png"].includes(value[0].type)
        );
      });
  }

  return baseSchema;
};
const KYC = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const { data, isLoading } = useGetSingleUserQuery();
  const [kycDetails] = useKycDetailsMutation();
  const [frontProofSelected, setFrontProofSelected] = useState(false);
  const [backProofSelected, setBackProofSelected] = useState(false);
  const user = data?.data;
  const userKycStatus = user?.kyc?.isApproved;
  // console.log(userKycStatus);
  const userKyc = user?.kyc;
  // console.log(userKyc?.upload?.frontSideStatus);
  const adminReply = userKyc?.adminComment;
  // console.log(adminReply);
  const navigate = useNavigate();

  const userUpdateStatus = userKyc?.userUpdateStatus;
  console.log(userKycStatus);

  const { handleSubmit, register, formState, setValue, reset } = useForm({
    resolver: yupResolver(createSchema("pending", "pending")),
    mode: "all",
  });

  useEffect(() => {
    // Set default values when user data is available
    if (user) {
      const { username, email } = user;
      setValue("username", username);
      setValue("email", email);
    }
  }, [user, setValue]);

  useEffect(() => {
    if (user && userKyc) {
      const { email, mobile, accountNo, proofType, address } = userKyc;

      setValue("mobile", mobile);
      setValue("accountNo", accountNo);
      setValue("proofType", proofType);
      setValue("address", address);
      const frontProofImage = userKyc.upload?.frontProof;
      const backProofImage = userKyc.upload?.backProof;

      if (frontProofImage) {
        document.getElementById(
          "frontProofPreview"
        ).src = `http://localhost:8080/${frontProofImage}`;
      }

      if (backProofImage) {
        document.getElementById(
          "backProofPreview"
        ).src = `http://localhost:8080/${backProofImage}`;
      }
    }
  }, [user, userKyc, setValue]);

  const onSubmit = async (data) => {
    const frontProofImg = data.frontProof && data.frontProof[0];
    const backProofImg = data.backProof && data.backProof[0];

    const formDataWithUserId = new FormData();

    // Append text data
    formDataWithUserId.append("username", data.username);
    formDataWithUserId.append("email", data.email);
    formDataWithUserId.append("mobile", data.mobile);
    formDataWithUserId.append("accountNo", data.accountNo);
    formDataWithUserId.append("proofType", data.proofType);
    formDataWithUserId.append("address", data.address);

    // Append image files
    formDataWithUserId.append("frontProof", frontProofImg);
    formDataWithUserId.append("backProof", backProofImg);

    try {
      const response = await kycDetails({
        userId: user?._id,
        userWithId: formDataWithUserId,
      });

      // console.log(response);
      if (response.data) {
        Swal.fire({
          icon: "success",
          title: "Success!",
          text: "Kyc updated successfully!",
        }).then(() => {
          navigate("/profile");
        });
      }
    } catch (error) {
      console.error("Error submitting KYC details:", error);
    }
  };
  if (isLoading) {
    return <h5>Loading...</h5>;
  }

  //ADMIN REPLY
  const ModalContent = () => (
    <div>
      <ModalHeader toggle={() => setIsModalOpen(false)}>
        Admin Reply
      </ModalHeader>
      <ModalBody style={{ border: 0 }}>
        <p dangerouslySetInnerHTML={{ __html: adminReply }} />
      </ModalBody>
      <ModalFooter>
        <Button
          className="btn BtnPrimry Btn-148-40 BtnScndry mr-2 mb-2"
          onClick={() => setIsModalOpen(false)}
        >
          OK
        </Button>
      </ModalFooter>
    </div>
  );

  //Status
  const getStatus = () => {
    if (
      userKyc?.upload?.frontSideStatus === "pending" ||
      userKyc?.upload?.backSideStatus === "pending"
    ) {
      return "Pending";
    } else if (
      userKyc?.upload?.frontSideStatus === "Declined" ||
      userKyc?.upload?.backSideStatus === "Declined"
    ) {
      return "Declined";
    } else {
      return "Approved";
    }
  };

  const renderStatus = () => {
    const status = getStatus();
    return (
      <p id="frontProofStatus" style={{ color: "yellow" }}>
        {status}
      </p>
    );
  };
  return (
    <>
      {/* <Header /> */}
      <div className="container-fluid">
        <div className="row">
          <div className="col-sm-12 col-md-auto col-lg-auto pgCntC-lt"></div>
          <div className="col-sm-12 col-md-12 col-lg pgCntC-rt">
            <div className="pgCntCon">
              <div className="pade_padding_wrap">
                <div className="d-flex justify-content-between">
                  <div className="InrPgHdrSec mb-4 ">
                    <h2>KYC</h2>
                    {/* <h4>
                      Status: Status:
                      {renderStatus()}
                    </h4> */}
                  </div>
                  <div>
                    <button
                      className="btn BtnPrimry fntsize Btn-182-44 m-auto"
                      onClick={() => setIsModalOpen(true)}
                    >
                      view Reply
                    </button>
                  </div>
                </div>

                <div className="row">
                  <div className="col-lg-12 mx-auto">
                    <div className="MyWlltTbbBox mt-120">
                      <div className="prfimgcd">
                      
                        <div className="upLo2">
                          {/* <div className="variants">
                            <div className="file">
                              <label htmlFor="input-file">
                                <img src="/static/images/edit.svg" alt="" />
                              </label>
                              <input
                                id="input-file"
                                type="file"
                                {...register("file")}
                              />
                            </div>
                          </div> */}
                        </div>
                      </div>
                      <form
                        className="pt-md-5 pt-3 pb-3"
                        onSubmit={handleSubmit(onSubmit)}
                      >
                        <div className="row">
                          <div className="col-lg-8 mx-auto">
                            <div className="row">
                              <div className="col-md-6">
                                <div className="Frmstl mb-20">
                                  {/* <h1>Username </h1> */}
                                  <div className="form-group">
                                    <input
                                      {...register("username")}
                                      type="text"
                                      className="form-control"
                                      placeholder="Enter your Username"
                                      readOnly
                                    />
                                    <p className="text-danger">
                                      {formState.errors.username?.message}
                                    </p>
                                  </div>
                                </div>
                              </div>
                              <div className="col-md-6">
                                <div className="Frmstl mb-20">
                                  {/* <h1>Email Id</h1> */}
                                  <div className="form-group">
                                    <input
                                      {...register("email")}
                                      type="email"
                                      className="form-control"
                                      placeholder="Enter your Email Id"
                                      readOnly
                                    />
                                    <p className="text-danger">
                                      {formState.errors.email?.message}
                                    </p>
                                  </div>
                                </div>
                              </div>
                              <div className="col-md-6">
                                <div className="Frmstl mb-20">
                                  {/* <h1>
                                    Mobile <span>*</span>
                                  </h1> */}
                                  <div className="form-group">
                                    <input
                                      {...register("mobile")}
                                      type="text"
                                      className="form-control"
                                      placeholder="Enter your mobile"
                                    />
                                    <p className="text-danger">
                                      {formState.errors.mobile?.message}
                                    </p>
                                  </div>
                                </div>
                              </div>
                              <div className="col-md-6">
                                <div className="Frmstl mb-20">
                                  {/* <h1>
                                    Account No <span>*</span>
                                  </h1> */}
                                  <div className="form-group">
                                    <input
                                      {...register("accountNo")}
                                      type="text"
                                      className="form-control"
                                      placeholder="Enter your Account No"
                                    />
                                    <p className="text-danger">
                                      {formState.errors.accountNo?.message}
                                    </p>
                                  </div>
                                </div>
                              </div>
                              <div className="col-md-6">
                                <div className="Frmstl mb-20">
                                  {/* <h1>Select Proof</h1> */}
                                  <div className="form-group">
                                    <select
                                      {...register("proofType")}
                                      className="form-control"
                                      id="exampleFormControlSelect1"
                                    >
                                      <option value="">Select Proof</option>
                                      <option value="PAN Card">PAN Card</option>
                                      <option value="Aadhar Card">
                                        Aadhar Card
                                      </option>
                                      <option value="Vote ID">Vote ID</option>
                                      <option value="Driving Licence">
                                        Driving Licence
                                      </option>
                                    </select>
                                    <p className="text-danger">
                                      {formState.errors.proofType?.message}
                                    </p>
                                  </div>
                                </div>
                              </div>
                              <div className="col-md-6">
                                <div className="Frmstl mb-20">
                                  {/* <h1>
                                    Address <span>*</span>
                                  </h1> */}
                                  <div className="form-group">
                                    <input
                                      {...register("address")}
                                      type="text"
                                      className="form-control"
                                      placeholder="Enter your Address"
                                    />
                                    <p className="text-danger">
                                      {formState.errors.address?.message}
                                    </p>
                                  </div>
                                </div>
                              </div>
                              <div className="col-md-6">
                                <div className="Frmstl mb-20">
                                  {/* <h1>
                                    Front Side ID Proof <span>*</span>
                                  </h1> */}
                                  <div className="form-group">
                                    <input
                                      name="frontProof"
                                      {...register("frontProof")}
                                      type="file"
                                      className="form-control"
                                      placeholder="Enter your Front Side ID Proof"
                                      onChange={(e) => {
                                        setFrontProofSelected(true);
                                        if (e.target.files.length > 0) {
                                          const frontProofImage =
                                            URL.createObjectURL(
                                              e.target.files[0]
                                            );
                                          document.getElementById(
                                            "frontProofPreview"
                                          ).src = frontProofImage;
                                        }
                                      }}
                                      disabled={
                                        userKyc?.upload?.frontSideStatus ===
                                        "Approved"
                                      }
                                    />
                                    <p className="text-danger">
                                      {formState.errors.frontProof?.message}
                                    </p>
                                  </div>
                                </div>
                              </div>
                              <div className="col-md-6">
                                <div className="Frmstl mb-20">
                                  {/* <h1>
                                    Back Side ID Proof <span>*</span>
                                  </h1> */}
                                  <div className="form-group">
                                    <input
                                      name="backProof"
                                      {...register("backProof")}
                                      type="file"
                                      className="form-control"
                                      placeholder="Enter your Back Side ID Proof"
                                      onChange={(e) => {
                                        if (e.target.files.length > 0) {
                                          setBackProofSelected(true);
                                          const backProofImage =
                                            URL.createObjectURL(
                                              e.target.files[0]
                                            );
                                          document.getElementById(
                                            "backProofPreview"
                                          ).src = backProofImage;
                                        }
                                      }}
                                      disabled={
                                        userKyc?.upload?.backSideStatus ===
                                        "Approved"
                                      }
                                    />
                                    <p className="text-danger">
                                      {formState.errors.backProof?.message}
                                    </p>
                                  </div>
                                </div>
                              </div>

                              <div class="col-md-6">
                                <div class="Frmstl mb-20">
                                  {/* <h1>
                                    Preview <span>*</span>
                                  </h1> */}
                                  <div class="form-group">
                                    <div className="proofpreview">
                                      <img
                                        id="frontProofPreview"
                                        alt="Back Proof Preview"
                                        style={{
                                          height: "150px",
                                          width: "210px",
                                        }}
                                      />
                                    </div>
                                    {frontProofSelected ? (
                                      ""
                                    ) : (
                                      <div>
                                        {userKyc?.upload?.frontSideStatus ===
                                          "Declined" && (
                                          <p style={{ color: "red" }}>
                                            FrontProofImage Declined
                                          </p>
                                        )}
                                        {userKyc?.upload?.frontSideStatus ==
                                          "Approved" && (
                                          <p style={{ color: "green" }}>
                                            Approved
                                          </p>
                                        )}
                                      </div>
                                    )}
                                  </div>
                                </div>
                              </div>
                              <div class="col-md-6">
                                <div class="Frmstl mb-20">
                                  {/* <h1>
                                    Preview <span>*</span>
                                  </h1> */}
                                  <div class="form-group">
                                    <div className="proofpreview">
                                      <img
                                        id="backProofPreview"
                                        alt="Back Proof Preview"
                                        style={{
                                          height: "150px",
                                          width: "210px",
                                        }}
                                      />
                                    </div>

                                    {backProofSelected ? (
                                      ""
                                    ) : (
                                      <div>
                                        {userKyc?.upload?.backSideStatus ===
                                          "Declined" && (
                                          <p style={{ color: "red" }}>
                                            BackProofImage Declined
                                          </p>
                                        )}
                                        {userKyc?.upload?.backSideStatus ===
                                          "Approved" && (
                                          <p style={{ color: "green" }}>
                                            Approved
                                          </p>
                                        )}
                                      </div>
                                    )}
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        {!userKycStatus && userUpdateStatus === false ? (
                          <>
                            <button
                              className="btn BtnPrimry fntsize Btn-182-44 m-auto"
                              type="submit"
                            >
                              Update
                            </button>
                          </>
                        ) : (
                          <></>
                        )}
                      </form>
                    </div>
                  </div>
                </div>
              </div>
              <footer>
                <div className="FtrSecMain">
                  <div className="container">
                    <div className="FtrCntMain text-center">
                      <div className="FtrCpyRt">
                        <p>© 2023 Osiz Support. All rights reserved.</p>
                      </div>
                    </div>
                  </div>
                </div>
              </footer>
            </div>
          </div>
        </div>
      </div>

      {isModalOpen && (
        <Modal
          isOpen={isModalOpen}
          toggle={() => setIsModalOpen(false)}
          modalClassName="CmmnMdl"
          className="modal-sm"
        >
          <ModalContent />
        </Modal>
      )}
    </>
  );
};

export default KYC;
