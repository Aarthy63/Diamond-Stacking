import React, { Fragment, useState, useEffect } from "react";
import { TabContent, TabPane, Nav, NavItem, NavLink } from 'reactstrap';
import classnames from 'classnames';
import Header from "../../components/Header/Header";
import Footer from "../../components/Footer/Footer";
import {
    Accordion,
    AccordionItem,
    AccordionItemHeading,
    AccordionItemButton,
    AccordionItemPanel,
} from 'react-accessible-accordion';
import { toast } from 'react-toastify'
import "react-toastify/dist/ReactToastify.css";
import 'react-accessible-accordion/dist/fancy-example.css';
import { useGetFAQDatasMutation } from "../redux/api";
 
 const Faq = (props) => {
    const [fetchingFaqDatas] = useGetFAQDatasMutation()

    const [faqDatas, setFaqDatas] = useState([])

    useEffect(() => {
        const fetchingFaq = async () => {
            try {
                const faqDataResponse = await fetchingFaqDatas()
                if (faqDataResponse.error) {
                    return toast.error('Fetching Data Error')
                }
                setFaqDatas(faqDataResponse.data.faqDatas)
            } catch (error) {
                console.log(error.message);
            }

        }
        fetchingFaq()
    }, [])

    const [activeTab, setActiveTab] = useState('1');

    const toggle = tab => {
        if(activeTab !== tab) setActiveTab(tab);
    }
  
    return (
      <Fragment>
        <Header />
        <div className="Main-section cmsSec faqSec">
            <div className="container container-1200">
                <div className="cmsBanner d-flex justify-content-center align-items-center">
                    <div>
                        <h3 className="text-center">How Can We Help?</h3>
                        <p className="text-center">Frequently Asked Questions</p>
                    </div>
                    <div className="searchCnt">
                        <input type="text" className="form-control" placeholder="Search" />
                    </div>
                </div>
                <div className="faqCnt">
                    <div className="row">
                        <div className="col-lg-3">
                            <Nav tabs>
                                <NavItem>
                                    <NavLink
                                        className={classnames({ active: activeTab === '1' })}
                                        onClick={() => { toggle('1'); }}
                                    >
                                        General
                                    </NavLink>
                                </NavItem>
                            </Nav>
                        </div>
                        {faqDatas.map((faqData, index) => (
                        <div className="col-lg-9">
                            <TabContent activeTab={activeTab}>
                                <TabPane tabId="1">
                                    <Accordion allowMultipleExpanded={false}>
                                        <AccordionItem>
                                            <AccordionItemHeading>
                                                <AccordionItemButton>
                                                <h6>{faqData.questions} ?</h6>
                                                </AccordionItemButton>
                                            </AccordionItemHeading>
                                            <AccordionItemPanel>
                                            <div style={{ fontSize: '1.3rem' }}
                                          dangerouslySetInnerHTML={{ __html: faqData.answers }} />
                                            </AccordionItemPanel>
                                        </AccordionItem>
                                    </Accordion>
                                </TabPane>                             
                            </TabContent>
                        </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
		<Footer />
      </Fragment>
    );
    
}

export default Faq;