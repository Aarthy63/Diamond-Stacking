import React, { Fragment, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import {
    TabContent, TabPane, Nav, NavItem, NavLink
} from 'reactstrap';
import classnames from 'classnames';

import fileUploadIcon from '../../assets/images/file-upload-icon.svg';
import vwTcktArrw from '../../assets/images/vw-tckt-arrw.svg';
import vwtcktInptIcon1 from '../../assets/images/vwtckt-inpt-icon1.svg';
import vwtcktInptIcon2 from '../../assets/images/vwtckt-inpt-icon2.svg';

import ReactDOM from "react-dom";
import {
    BrowserRouter, Navigate, Route, Routes, Link
} from 'react-router-dom';
import {
    Accordion,
    AccordionItem,
    AccordionItemHeading,
    AccordionItemButton,
    AccordionItemPanel,
} from 'react-accessible-accordion';
import { useProfileDetailsUpdateMutation, useGetProfileDetailsMutation } from '../redux/api'
// Demo styles, see 'Styles' section below for some notes on use.
import 'react-accessible-accordion/dist/fancy-example.css';
import {toast} from 'react-toastify'
import { yupResolver } from "@hookform/resolvers/yup";
import * as Yup from "yup";

const validationSchema = Yup.object().shape({

    name: Yup.string()
        .required(" Name is required")
        .matches(
            /^[_A-zA-Z]*((-|\s)*[_A-zA-Z])*$/g,
            "Name is Should be characters only"
        )
        .trim(),

    email: Yup.string()
        .required("Email is required")
        .matches(/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i, "Enter valid Email")
        .email("Email is invalid")
        .trim(),

    number: Yup.string()
        .required("Number is required")
        .min(10, "Number should have 10 digits only")
        .max(10, "Number should be in 10 digits")
        .matches(/^[6-9]\d{9}$/, "Enter valid number")
        .trim(),

    state: Yup.string()
        .required(" State is required")
        .matches(
            /^[_A-zA-Z]*((-|\s)*[_A-zA-Z])*$/g,
            "State is Should be characters only"
        )
        .trim(),
    comments: Yup.string()
        .required(" Comments is requrired")
        .matches(
            /^[_A-zA-Z]*((-|\s)*[_A-zA-Z])*$/g,
            "State is Should be characters only"
        )
        .trim(),
});

// functions to build form returned by useForm() hook

const DsbPages = (props) => {

    const loggedUserId = localStorage.getItem('userId')
    const [profileImg, setProfileImg] = useState();
    const [userProfileUpdate] = useProfileDetailsUpdateMutation();
    const [userProfileDetails] = useGetProfileDetailsMutation();
    const [activeTab, setActiveTab] = useState('1');

    const toggle = tab => {
        if (activeTab !== tab) setActiveTab(tab);
    }

    const {
        register,
        handleSubmit,
        reset,
        formState: { errors },
    } = useForm({
        resolver: yupResolver(validationSchema),
        mode: "all",
    });
   


    const handleUserDataDetails = async (data) => {
       
        const formData = new FormData();
        try {
            formData.append('name', data.name);
            formData.append('number', data.number)
            formData.append('email', data.email);
            formData.append('state', data.state);
            formData.append('id', loggedUserId)

            const profileUpdateReponse = await userProfileUpdate(formData);
            if (profileUpdateReponse.error) {
                   toast.error('Profile Error', {
                     position: toast.POSITION.TOP_CENTER,
                   });
                return;
            }
             toast.success(profileUpdateReponse.data.message, {
               position: toast.POSITION.TOP_CENTER,
             });
        } catch (error) {
            toast.error(error.data.message)
            console.error('Error updating item:', error);
            // You can add further error handling logic here, such as displaying an error message to the user.
        }
    };
    useEffect(() => {
        // post on submit update function
        handleUserDataDetails({
            name: 'asdf',
            number: '61',
            email: 'asdfa',
            state: 'asdfs',
            comments: 'asdfa',
        });

        // get user details
        const fetchUserData = async () => {
            try {
                const profileUpdateReponse = await userProfileDetails({
                    id: loggedUserId
                });
                reset({
                    name: userData.name,
                    number: userData.phoneNo,
                    email: userData.email,
                    state: userData.state,
                    comments: userData.Comments
                })
                const userData = profileUpdateReponse.data.getUserDetails;
                // setProfileImg(userData.profileImg);
                // setDobInfo(userData.personalInfo.DOB)
            } catch (err) {
                console.log(err.message);
            }
        };
        fetchUserData();
    }, []);


    return (
        <Fragment>
            <div className="DbCntMain">
                <div className="BluBg107 SwapMainSec BluBgLight">
                    <div className="SwpHdd mb-4">
                        <h4>Support</h4>
                    </div>
                    <div className="BluBg0b0 SwpFrMainSec StkFrmMain">
                        <div className="SupprtTbbSec">
                            <TabContent activeTab={activeTab}>
                                <TabPane tabId="1">
                                    <form className="SupprtFrmMain" onSubmit={handleSubmit(handleUserDataDetails)}>
                                        <div className="row">
                                            <div className="col-lg-6">
                                                <div className="form-group ">
                                                    <label for="input2" className="FrmLbl">Name<span>*</span></label>
                                                    <input
                                                        name="Name"
                                                        type="text"
                                                        {...register("name")}
                                                        className={`form-control ${errors.name ? "is-invalid" : ""
                                                            }`}
                                                        placeholder="Enter Your Name"
                                                    />
                                                    <div
                                                        className="invalid-feedback"
                                                        style={{ marginLeft: "10%", fontFamily: "monospace" }}
                                                    >
                                                        {errors.name?.message}
                                                    </div>
                                                </div>
                                                <div className="form-group ">
                                                    <label for="inputEmail4" className="FrmLbl">Email<span>*</span></label>
                                                    <input
                                                        name="Email"
                                                        type="text"
                                                        {...register("email")}
                                                        className={`form-control ${errors.email ? "is-invalid" : ""
                                                            }`}
                                                        placeholder="Enter Your E-mail"
                                                    />
                                                    <div
                                                        className="invalid-feedback"
                                                        style={{ marginLeft: "10%", fontFamily: "monospace" }}
                                                    >
                                                        {errors.email?.message}
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-lg-6">
                                                <div className="form-group ">
                                                    <label for="inputEmail4" className="FrmLbl">Number<span>*</span></label>
                                                    <input
                                                        name="Number"
                                                        type="text"
                                                        {...register("number")}
                                                        className={`form-control ${errors.number ? "is-invalid" : ""
                                                            }`}
                                                        placeholder="Enter Your Phone Number"
                                                    />
                                                    <div
                                                        className="invalid-feedback"
                                                        style={{ marginLeft: "10%", fontFamily: "monospace" }}
                                                    >
                                                        {errors.number?.message}
                                                    </div>
                                                </div>
                                                <div className="form-group ">
                                                    <label for="inputEmail4" className="FrmLbl">State<span>*</span></label>
                                                    <input
                                                        name="State"
                                                        type="text"
                                                        {...register("state")}
                                                        className={`form-control ${errors.state ? "is-invalid" : ""
                                                            }`}
                                                        placeholder="Enter Your State"
                                                    />
                                                    <div
                                                        className="invalid-feedback"
                                                        style={{ marginLeft: "10%", fontFamily: "monospace" }}
                                                    >
                                                        {errors.state?.message}
                                                    </div>
                                                </div>
                                                <div className="form-group ">
                                                    <label for="exampleFormControlTextarea1" className="FrmLbl">Comments<span>*</span></label>
                                                    <textarea  {...register("comments")} className={`form-control ${errors.comments ? "is-invalid" : ""
                                                        }`}
                                                        placeholder="Enter Your State" id="exampleFormControlTextarea1" rows="5"></textarea>
                                                    <div
                                                        className="invalid-feedback"
                                                        style={{ marginLeft: "10%", fontFamily: "monospace" }}
                                                    >
                                                        {errors.comments?.message}
                                                    </div>
                                                </div>

                                                {/* <div className="form-group ">
                                                    <label for="exampleFormControlTextarea1" className="FrmLbl">Add Attachment</label>
                                                    <div className="uploadFile">
                                                        <div className="uploadFileFlx">
                                                            <div className="fileCnt">
                                                                <p>Select or drop image here</p>
                                                                <span>Max file size is 100Kb</span>
                                                            </div>
                                                            <div className="fileUpldIcon">
                                                                <img src={fileUploadIcon}  {...register('profileImg')} alt="" className="img-fluid" onChange={handleFileChange} />
                                                            </div>
                                                            <div
                                                                className="invalid-feedback"
                                                                style={{ marginLeft: "10%", fontFamily: "monospace" }}
                                                            >
                                                                {errors.profileImg?.message}
                                                            </div>
                                                        </div>
                                                        <input type="file" className="inputfile form-control" name="file" />
                                                    </div>
                                                </div> */}
                                            </div>
                                        </div>
                                        <div className="text-center SwpMainBtn mt-3 mt-md-5">
                                            <button type="submit" className="btn BtnPrimry Btn160-42">Submit</button>
                                        </div>
                                    </form>
                                </TabPane>
                            </TabContent>
                        </div>
                    </div>
                </div>
            </div>
        </Fragment>
    );

}

export default DsbPages;