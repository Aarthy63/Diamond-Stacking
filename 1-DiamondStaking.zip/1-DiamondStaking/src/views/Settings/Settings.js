import React, { Fragment, useEffect, useState } from "react";
import { Container, Row, Col, Modal, ModalHeader, ModalBody, UncontrolledDropdown, DropdownToggle, DropdownMenu, DropdownItem,
	Collapse,
	Navbar,
	NavbarToggler,
	NavbarBrand,
	Nav,
	NavItem, NavLink
} from 'reactstrap';
import Header from "../../components/GovHeader/GovHeader";
import gvrPrflImg from '../../assets/images/gvr-prfl-img.png';
import tickIcon from '../../assets/images/tick-icon.svg';
import hdrCopyIcon from '../../assets/images/hdr-copy-icon.svg';
import backArrow from '../../assets/images/backArrow.svg';
import infoIcon from '../../assets/images/info-icon.svg';
import profile from '../../assets/images/profile.png';
import telegram from '../../assets/images/telegram.svg';
import twitter from '../../assets/images/twitter.svg';
import discord from '../../assets/images/discord.svg';
import insta from '../../assets/images/insta.svg';
import { useProfileDetailsUpdateMutation, useGetProfileDetailsMutation } from '../redux/api'
import ReactDOM from "react-dom";
import {
	BrowserRouter, Navigate, Route, Routes, Link
 } from 'react-router-dom';
import 'react-accessible-accordion/dist/fancy-example.css';
import {toast} from 'react-toastify'
import { yupResolver } from "@hookform/resolvers/yup";
import * as Yup from "yup";
import {useForm} from'react-hook-form'
 
const validationSchema = Yup.object().shape({
    name: Yup.string()
        .required(" Name is required")
        .matches(
            /^[_A-zA-Z]*((-|\s)*[_A-zA-Z])*$/g,
            "Name is Should be characters only"
        )
        .trim(),

    about: Yup.string()
        .required("About is required")
        .trim(),
    });

 const DsbPages = (props) => {
    
    const loggedUserId = localStorage.getItem('userId')
    const [profileImg, setProfileImg] = useState();
    const [userProfileUpdate] = useProfileDetailsUpdateMutation();
    const [userProfileDetails] = useGetProfileDetailsMutation();
    const [activeTab, setActiveTab] = useState('1');

    const toggle = tab => {
        if (activeTab !== tab) setActiveTab(tab);
    }

    const {
        register,
        handleSubmit,
        reset,
        formState: { errors },
    } = useForm({
        resolver: yupResolver(validationSchema),
        mode: "all",
    });
   


    const handleUserDataDetails = async (data) => {
       
        const formData = new FormData();
        try {
            formData.append('name', data.name);
            formData.append('about', data.about)
           
            const profileUpdateReponse = await userProfileUpdate(formData);
            if (profileUpdateReponse.error) {
                   toast.error('Profile Error', {
                     position: toast.POSITION.TOP_CENTER,
                   });
                return;
            }
             toast.success(profileUpdateReponse.data.message, {
               position: toast.POSITION.TOP_CENTER,
             });
        } catch (error) {
            toast.error(error.data.message)
            console.error('Error updating item:', error);
            // You can add further error handling logic here, such as displaying an error message to the user.
        }
    };
    useEffect(() => {
        // post on submit update function
        handleUserDataDetails({
            name: 'asdf',
            about: '61',
           
        });

        // get user details
        const fetchUserData = async () => {
            try {
                const profileUpdateReponse = await userProfileDetails({
                    id: loggedUserId
                });
                reset({
                    name: userData.name,
                    about: userData.about,
                   
                })
                const userData = profileUpdateReponse.data.getUserDetails;
                setProfileImg(userData.profileImg);
            } catch (err) {
                console.log(err.message);
            }
        };
        fetchUserData();
    }, []);


  
    return (
      <Fragment>
        <Header />
        <div className="Main-section ">
            <div className="container container-1200">
                <div className="GvrnceMain">
                    <div className="row mx-0">
                        <div className="col DbSdCol px-0">
                            <div className="GoverSdmnu">
                                <div className="DbSdMnu dbScrl">
                                    <div className="DbSdMnuTop">
                                        <div className="MblViewCnt">
                                            <ul className="d-flex align-items-center">
                                                <li>
                                                    <button className="btn AftrLgnBtn Btn202-42"><span><img src={hdrCopyIcon} alt="" className="img-fluid" /> </span>0x35sdf41g6sd4gs...</button>
                                                </li>
                                            </ul>
                                        </div>
                                        <div className="dbSbMenu">
                                            <ul className="pt-4">
                                                <li className="">
                                                    <a href="governance.html">
                                                        <span className="sbMTx">General</span>
                                                    </a>
                                                </li>
                                                <li className="">
                                                    <a href="new-proposal.html">

                                                        <span className="sbMTx">Voting</span>
                                                    </a>
                                                </li>
                                                <li className="">
                                                    <a href="stake.html">

                                                        <span className="sbMTx">Members</span>
                                                    </a>
                                                </li>
                                                  <li className="">
                                                    <a href="stake.html">
                                                        <span className="sbMTx">Members</span>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col DbMainCnt">
                            <div className="PrpsalMain BluBgLight1">
                                <div className="BluBg107 mb-4">
                                    <div className="settingsHeading mb-4">
                                        <a><img src={backArrow} className="mr-3" /></a>
                                        <h3>Settings</h3>
                                    </div>
                                    <div className="BluDrkBg mb-4">
                                        <p><img src={infoIcon} alt="" className="img-fluid mr-2" /> You are in view only mode, to modify space settings connect with a controller or admin wallet.</p>
                                    </div>
                                    <form className="SupprtFrmMain" onSubmit={handleSubmit(handleUserDataDetails)}></form>
                                    <div className="d-flex flex-column">
                                        <h3 className="secHeading">Profile</h3>
                                        <div className="BluDrkBg mb-4">
                                            <div className="d-flex flex-wrap">
                                                <div className="profPicCnt mb-auto">
                                                    <img src={profile} className="profPic" />
                                                </div>
                                                 <form className="SupprtFrmMain NewPrpsFrm w-75">
                                                    <div className="row">
                                                        <div className="col-12">
                                                            <div className="form-group ">
                                                                <label for="inputEmail4" className="FrmLbl">Name</label>
                                                                <input
                                                        name="Name"
                                                        type="text"
                                                        {...register("name")}
                                                        className={`form-control pl-4 ${errors.name ? "is-invalid" : ""
                                                            }`}
                                                        placeholder="Enter Your Name"
                                                    />
                                                    <div
                                                        className="invalid-feedback"
                                                        style={{ marginLeft: "10%", fontFamily: "monospace" }}
                                                    >
                                                        {errors.name?.message}
                                                    </div>
                                                            </div>
                                                            <div className="form-group ">
                                                                <label for="inputEmail4" className="FrmLbl">About</label>
                                                                <textarea
                                                        name="Name"
                                                        type="text"
                                                        {...register("about")}
                                                        className={`form-control pl-4 ${errors.about ? "is-invalid" : ""
                                                            }`}
                                                        placeholder="Enter Your Name"
                                                    />
                                                    <div
                                                        className="invalid-feedback"
                                                        style={{ marginLeft: "10%", fontFamily: "monospace" }}
                                                    >
                                                        {errors.about?.message}
                                                    </div>
                                                            </div>
                                                        </div>
                                                        <button className="btn BtnPrimry Btn120-42 center" style={{marginLeft:'120px'}}>Submit</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                

                                    <div className="d-flex flex-column">
                                        <h3 className="secHeading">Social Accounts</h3>
                                        <div className="BluDrkBg mb-4">
                                            <div className="d-flex flex-wrap">
                                                <div className="socialCnt">
                                                    <div className="socialIcon">
                                                        <img src={telegram} />
                                                    </div>
                                                    <p className="mb-0">eg: teleport@123</p>
                                                </div>

                                                <div className="socialCnt">
                                                    <div className="socialIcon">
                                                        <img src={twitter} />
                                                    </div>
                                                    <p className="mb-0">eg: teleport@123</p>
                                                </div>

                                                <div className="socialCnt">
                                                    <div className="socialIcon">
                                                        <img src={discord} />
                                                    </div>
                                                    <p className="mb-0">eg: teleport@123</p>
                                                </div>

                                                <div className="socialCnt">
                                                    <div className="socialIcon">
                                                        <img src={insta} />
                                                    </div>
                                                    <p className="mb-0">eg: teleport@123</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
		
      </Fragment>
    );
    
}

export default DsbPages;