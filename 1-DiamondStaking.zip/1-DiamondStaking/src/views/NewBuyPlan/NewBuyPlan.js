// import React, { Component, Fragment, useState, useRef, useEffect, createRef  } from "react";
// // import "../style.scss";
// // import { Link, useHistory } from "react-router-dom/cjs/react-router-dom.min";
// import { useNavigate, Link } from "react-router-dom";
// // import ProgressBar from "./Progress/Progress";
// // import logoImg from '../assets/images/logonew.png';
// // import homeImg from '../assets/images/home-2.svg';
// // import menu3ftImg from '../assets/images/menu-3.svg';
// // import closeImg from '../assets/images/close.svg'
// // import cardImage from '../assets/images/logonew.png'
// import { usePlanDataQuery } from "../redux/api";


// const Newbuyplan = (props) =>{   

//     const navigate = useNavigate();
//     const { isLoading, data, isSuccess, isError }= usePlanDataQuery()
//     const [state, setState] = useState(10);
//     const [isActive, setActive] = useState(false);
//     // let history= useHistory()
//         const SidemenuToggleClass = () => {
//           setActive(!isActive); 
//         };

//         if (isLoading) {
//             return <p>Loading...</p>;
//           }
        
//           if (isError) {
//             return <p>Error loading data</p>;
//           }
//           let plan;
//           if (isSuccess) {
//             plan=data.getAllplan
//         }
        
//   const handleBuyNow = (planId) => {
//      navigate(`/BuyPlan/${planId}`)

//   };


// return (
// <Fragment>
// <div className="pgVwContFt">
//  				<div className="pgVwContFtRl">							
// 					<div className="container-fluid">
// 					  	<div className="row align-items-center justify-content-between pgFtR">
// 					  		{/* <div className="col-4 col-sm-4 ftLogo">
//                                <Link to="/">
//  					  				<img src={logoImg} alt="logo" />
//  					  			</Link>
//  					  		</div> */}

//  					  		<div className="col-4 col-sm-4">
//  					  			<div className="ftMenu">
//  					  				{/* <a href="#" className="btn btn-6060 btn-menu">
//  					  					<img className="yt-2" src={homeImg} alt="home-2" />
//  					  				</a> */}
//  					  			</div>
// 					  		</div>

//  					  		<div className="col-4 col-sm-4">
//                                <div className="ftMr">
// 								  	<button className="btn btnSb" type="button"  onClick={SidemenuToggleClass}>
// 								    	{/* <img src={menu3ftImg} alt="menu-3 " /> */}
//  								    	<span className="ml-2">MENU</span>
//  								  	</button>
//  							  	</div>
//  					  		</div>
//  					  	</div>
//  				  	</div>
//  				</div>
//  			</div>
       
// 			<div className={isActive ? "sibeBarOl sbOpen" : "sibeBarOl"}></div>
//    <section className='loginregister'>
//     <h1 className=" text-center"> Staking Plan</h1>
//     <div className="row row-cols-1 row-cols-md-2 g-4">
//   {plan.map((plandata) => (
//     <div className="col" key={plandata._id}>
//       <div className="card w-60 border-primary"  style={{ backgroundImage: 'linear-gradient(to right, #fa709a 0%, #fee140 100%)' }}>
//         <div className="card-body">
//           <h5 className="card-title">{plandata.planname}</h5>
//           <p className="card-text">
//             Staking is also a way to contribute to the security and efficiency of the blockchain projects you support.
//           </p>
//           <div className="input-group">
//             <p className="input-group-text ">{plandata.planmonth} MONTHS</p>
//             <p className="input-group-text">{plandata.planinterest} %</p>
//           </div>
//           <button className=" mt-2 btn btn-warning" key={plandata._id}  onClick={() => {handleBuyNow(plandata._id); }}>Buy Now!</button>
//         </div>
//       </div>
//     </div>
//   ))}
// </div>
      
//    </section>
// </Fragment>
// );
// }
// export default Newbuyplan;