import PrivateRoute from "../PrivateRouter/PrivateRouter";
import React, { Fragment, useEffect, useState } from "react";
import {
    Container, Row, Col, Modal, ModalHeader, ModalBody, UncontrolledDropdown, DropdownToggle, DropdownMenu, DropdownItem,
    Collapse,
    Navbar,
    NavbarToggler,
    NavbarBrand,
    Nav,
    NavItem, NavLink
} from 'reactstrap';
import Web3 from "web3";
import { ContractABI } from "../getaccounts/ContractABI";
import Dashboard from '../Dashboard/Dashboard';
import Swap from '../Swap/Swap';
import Stake from '../Stake/Stake';
import StakeOne from '../StakeOne/StakeOne';
import Unstake from '../Unstake/Unstake';
import Bond from '../Bond/Bond';
import BondOne from '../BondOne/BondOne';
import BondTwo from '../BondTwo/BondTwo';
import TransactionHistory from '../StakingDetails/StakingDetails';
import Profile from '../Support/Profile'
import PlanList from '../PlanList/PlanList';
import BuyPlan from '../BuyPlan/BuyPlan';
import StakingDetails from "../StakingDetails/StakingDetails";
import FASecurityPage from "../SecurityPage/FASecurityPage";
import sdemnuIcon1 from '../../assets/images/sde-mnu-icon1.svg';
import sdemnuIcon2 from '../../assets/images/sde-mnu-icon2.svg';
import sdemnuIcon3 from '../../assets/images/sde-mnu-icon3.svg';
import sdemnuIcon4 from '../../assets/images/sde-mnu-icon4.svg';
import sdemnuIcon5 from '../../assets/images/sde-mnu-icon5.svg';
import sdemnuIcon6 from '../../assets/images/sde-mnu-icon6.svg';
import sdemnuIcon7 from '../../assets/images/sde-mnu-icon7.svg';
import dbMnuSclIcon1 from '../../assets/images/db-mnu-scl-icon1.svg';
import dbMnuSclIcon2 from '../../assets/images/db-mnu-scl-icon2.svg';
import dbMnuSclIcon3 from '../../assets/images/db-mnu-scl-icon3.svg';
import dbMnuSclIcon4 from '../../assets/images/db-mnu-scl-icon4.svg';
import logoInr from '../../assets/images/logo.png';

import metamask from '../../assets/images/MetaMask.svg';
import mdlCloseIcon from '../../assets/images/mdl-close-icon.svg';

import ReactDOM from "react-dom";
import {
    BrowserRouter, Navigate, Route, Routes, Link
} from 'react-router-dom';
import KYC from "../KYC/KYC";
import unstake from "../Unstake/Unstake";

const DsbPages = (props) => {
    const userId = localStorage.getItem("userId");
    const [address, setAddress] = useState("");
    const [balance, setBalance] = useState("");
    const [web3, setWeb3] = useState(null);
    const [block, setBlock] = useState();


    const [currentAccount, setCurrentAccount] = useState(null);
    const [myContract, setMyContract] = useState(null); // State to store contract instance
    const [contractAddress, setContractAddress] = useState("0x8c851d1a123ff703bd1f9dabe631b69902df5f97");

    useEffect(() => {
        if (window.ethereum) {
            try {
                console.log("Initializing Web3...");
                const web3Instance = new Web3(window.ethereum);
                setWeb3(web3Instance);

                const contractAddress = "0x50d0032257F98FfEE9492452121C9D1C584087d8";
                const contractInstance = new web3Instance.eth.Contract(ContractABI,
                    contractAddress);
                setMyContract(contractInstance);
            } catch (error) {
                console.error("Error initializing Web3:", error);
            }
        } else {
            console.error("MetaMask not installed.");
        }
    }, []);

    const handleAllActions = async () => {

        try {
            console.log("Requesting accounts...");
            const accounts = await window.ethereum.request({
                method: "eth_requestAccounts"
            });
            console.log("Connected accounts:", accounts);
            setAddress(accounts);
            setCurrentAccount(accounts[0]);

            if (accounts.length > 0) {
                web3.eth.getBalance(accounts[0]).then((balance) => {
                    const balanceInEther = web3.utils.fromWei(balance, "ether");
                    console.log("Balance in Ether:", balanceInEther);
                    setBalance(balanceInEther);
                });
            } else {
                console.error("MetaMask not connected. Please connect your wallet.");
            }

            console.log("Switching network...");
            await window.ethereum.request({
                method: "wallet_switchEthereumChain",
                params: [
                    {
                        chainId: "0x38"
                    }
                ]
            });
            console.log("Network switched successfully.");

            console.log("Fetching block number...");
            const blockNumber = await web3.eth.getBlockNumber();
            console.log("Block number:", blockNumber);
            setBlock(blockNumber);

            if (!currentAccount) {
                alert("Please connect your wallet first.");
                return;
            }

            console.log("Interacting with the contract...");
            const contractResult = await interactWithContract();
            console.log("Contract interaction result:", contractResult);
        } catch (error) {
            console.error("Error in handleAllActions:", error);
        }
    };

    const interactWithContract = async () => {
        if (!currentAccount) {
            alert("Please connect your wallet first.");
            return;
        }
        // Replace with your logic to interact with the contract on BscScan
        window.open(`https://bscscan.com/token/${contractAddress}#code`, '_blank');
    };

    const [isActive, setActive] = useState("false");
    const ToggleClass = () => {
        setActive(!isActive);
    };
    const [modal, setModal] = useState(false);
    const toggle = () => setModal(!modal);

    function PrivateRoute({ component }) {
        const isAuthenticated = localStorage.getItem("userId");

        if (isAuthenticated) {
            return component;
        } else {
            return <Navigate to="/Login" />;
        }
    }


    return (
        <Fragment>
            <div className={isActive ? null : "side-Open"}>
                <header class="Hddrg InrHddr FxdHeader">
                    <div class="FxedTop">
                        <nav class="navbar navbar-expand-lg">
                            <div class="container-fluid px-0">
                                <div class="LogoTitlSec">
                                    <div class="logo_header align-items-center InrLogoSec">
                                        <a class="navbar-brand" href="index.html">
                                            <img src={logoInr} class="img-fluid" />
                                        </a>
                                        <div class="SidRitMnu" onClick={ToggleClass}>
                                            <svg id="hamburger" onclick="this.classList.toggle('active')" viewBox="0 0 100 100">
                                                <rect class="hamburger-line hamburger-line-1" x="20" y="50" rX="1" width="60" height="2" />
                                                <rect class="hamburger-line  hamburger-line-2" x="20" y="50" rX="1" width="60" height="2" />
                                                <rect class="hamburger-line  hamburger-line-3" x="20" y="50" rX="1" width="60" height="2" />
                                            </svg>
                                        </div>
                                    </div>
                                    <div class="HdrTitlSec ml-4">
                                        <div class="HdrTitlCnt">
                                            <h4>Dashboard</h4>
                                        </div>
                                    </div>
                                </div>
                                <div class="DskTpViewCnt">
                                    <ul class="d-flex align-items-center">
                                        <li>
                                            <a href="#" class="btn BtnPrimry mr-3 Btn160-42" onClick={toggle}>Connect Wallet</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </nav>
                    </div>
                </header>

                <div className="DbMain">
                    <div className="container-fluid px-0">
                        <div className="row mx-0">
                            <div className="col DbSdCol">
                                <div className="DbSdMnu dbScrl">
                                    <div className="DbSdMnuTop">
                                        <div className="MblViewCnt">
                                            <ul className="d-flex align-items-center">
                                                <li>
                                                    <a href="#" className="btn BtnPrimry mr-3 Btn160-42" onClick={toggle}>Connect Wallet</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div className="dbSbMenu">
                                            <ul>
                                                <li className="active">
                                                    <Link to="/dash">
                                                        <span className="sbMIc">
                                                            <img src={sdemnuIcon1} alt="" className="mr-2" />
                                                        </span>
                                                        <span className="sbMTx">Dashboard</span>
                                                    </Link>
                                                </li>
                                                <li className="">
                                                    <Link to="/FaSecurtiyPage">
                                                        <span className="sbMIc">
                                                            <img src={sdemnuIcon2} alt="" className="mr-2" />
                                                        </span>
                                                        <span className="sbMTx">2FA</span>
                                                    </Link>
                                                </li>
                                                <li className="">
                                                    <Link to="/kyc">
                                                        <span className="sbMIc">
                                                            <img src={sdemnuIcon3} alt="" className="mr-2" />
                                                        </span>
                                                        <span className="sbMTx">KYC verification</span>
                                                    </Link>
                                                </li>
                                                <li className="">
                                                    <Link to="/PlanList">
                                                        <span className="sbMIc">
                                                            <img src={sdemnuIcon4} alt="" className="mr-2" />
                                                        </span>
                                                        <span className="sbMTx">PlanList</span>
                                                    </Link>
                                                </li>
                                                <li className="">
                                                    <a href="/BuyPlan">
                                                        <span className="sbMIc">
                                                            <img src={sdemnuIcon5} alt="" className="mr-2" />
                                                        </span>
                                                        <span className="sbMTx">BuyPlan</span>
                                                    </a>
                                                </li>
                                                <li className="">
                                                    <a href="/Unstake">
                                                        <span className="sbMIc">
                                                            <img src={sdemnuIcon5} alt="" className="mr-2" />
                                                        </span>
                                                        <span className="sbMTx">RewardClaiming</span>
                                                    </a>
                                                </li>
                                                <li className="">
                                                    <Link to="/StakingDetails">
                                                        <span className="sbMIc">
                                                            <img src={sdemnuIcon6} alt="" className="mr-2" />
                                                        </span>
                                                        <span className="sbMTx">StakingDetails</span>
                                                    </Link>
                                                </li>
                                                <li className="">
                                                    <Link to="/Profile">
                                                        <span className="sbMIc">
                                                            <img src={sdemnuIcon7} alt="" className="mr-2" />
                                                        </span>
                                                        <span className="sbMTx">Profile</span>
                                                    </Link>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                    <div className="DbFtrMenu">
                                        <div className="SclIcnSec text-center">
                                            <div className="SclIcnHdd mb-3">
                                                <h4>Follow US</h4>
                                            </div>
                                            <div className="SocialIcon mb-4">
                                                <ul>
                                                    <li>
                                                        <a href="#"><img src={dbMnuSclIcon1} className="img-fluid" /></a>
                                                    </li>
                                                    <li>
                                                        <a href="#"><img src={dbMnuSclIcon2} className="img-fluid" /></a>
                                                    </li>
                                                    <li>
                                                        <a href="#"><img src={dbMnuSclIcon3} className="img-fluid" /></a>
                                                    </li>
                                                    <li>
                                                        <a href="#"><img src={dbMnuSclIcon4} className="img-fluid" /></a>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div className="DbCpyRyt">
                                                <p>© 2023 OSIZ - All Rights Reserved.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="col DbMainCnt">
                                <Routes>
                                    <Route path="/dashboard" element={
                                            <PrivateRoute>
                                                <Dashboard />
                                            </PrivateRoute>}/>
                                    <Route path="/dash" element={<Dashboard/>}/>
                                    <Route path="/Unstake" element={<Unstake userId={userId} />} />
                                    <Route path="/FASecurityPage" element={
                                            <PrivateRoute>
                                                <FASecurityPage />
                                            </PrivateRoute>}/>
                                     <Route path="/StackingDetails" element={
                                            <PrivateRoute>
                                                <StakingDetails />
                                            </PrivateRoute>}/>
                                    {/* <Route path="/Profile" element={
                                            <PrivateRoute>
                                                <Profile />
                                            </PrivateRoute>}/> */}
                                     <Route path="/BuyPlan/:id" element={
                                            <PrivateRoute>
                                                <BuyPlan />
                                            </PrivateRoute>}/>
                                     <Route path="/Planlist" element={
                                            <PrivateRoute>
                                                <PlanList />
                                            </PrivateRoute>}/>
                                     <Route path="/KYC" element={
                                            <PrivateRoute>
                                                <KYC />
                                            </PrivateRoute>}/>

                                </Routes>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <Modal isOpen={modal} toggle={toggle} modalClassName="fade CmmnMdl ClaimMdl" className="modal-dialog-centered">
                <div className="BluBg107 ClaimMdlSec mb-4">
                    <div className="BwCloseIcn">
                        <button className="btn btn-link close" type="button" onClick={toggle}><img src={mdlCloseIcon} alt="" className="img-fluid" /> </button>
                    </div>
                    <div className="ClmRwrdHdd mb-4 text-center">
                        <h5>Connect Wallet</h5>
                    </div>
                    <div className="StkBlnDtlsFlx d-block">
                        <div className="StkBlnDtls1">
                            <img src={metamask} className="img-fluid d-block mx-auto" />
                            <p className="text-center" style={{ marginTop: '-25px' }}>Metamask</p>
                        </div>
                        <div>
                            {balance && <p className="text-center" style={{ marginTop: '-25px' }}>Balance: {balance}</p>}
                        </div>
                        <button onClick={handleAllActions} className="btn BtnPrimry Btn120-42 center" style={{ marginLeft: '80px' }}>
                            Connect </button>
                    </div>
                </div>
            </Modal>
        </Fragment>
    );

}

export default DsbPages;