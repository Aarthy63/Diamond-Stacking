import React, { useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { ToastContainer, toast } from 'react-toastify';
import "react-toastify/dist/ReactToastify.css";
import * as yup from 'yup';
import { BiRightArrowAlt } from 'react-icons/bi';
import { MdOutlinePublishedWithChanges } from 'react-icons/md';
import { MdCalendarMonth } from 'react-icons/md';
import { AiOutlinePercentage } from 'react-icons/ai';
import { MdOutlineDriveFileRenameOutline } from 'react-icons/md';
import stakingListImage from '../../../assets/images/avatars/Checklist.jpg';  // Replace with the actual path to your image

import {
  CButton,
  CCard,
  CCardBody,
  CCardGroup,
  CCol,
  CContainer,
  CFormInput,
  CInputGroup,
  CInputGroupText,
  CRow,
} from '@coreui/react';
import { useGetplanMutation, useUpdateplanMutation } from '../../../redux/services/adminAPI';

const schema = yup.object().shape({
  planname: yup
    .string()
    .required('Plan Name is required.')
    .min(3, 'Minimum 3 characters are allowed.')
    .max(15, 'Name has reached the maximum limit!')
    .matches(/^[A-Z -]+$/, 'Enter a valid name only'),
  planmonth: yup.string().required('Month is required.').matches(/^[0-9 -]+$/, 'Enter a valid amount'),
  planinterest: yup
    .string()
    .required('Enter interest amount')
    .matches(/^[0-9]+(\.[0-9]+)?$/, 'Enter a valid amount'),
});

const UpdatestakingPlan = () => {
  const adminId = localStorage.getItem('adminId');
  const navigate = useNavigate();
  const { id } = useParams();
  const [handleedit] = useGetplanMutation();
  const [handleupdate] = useUpdateplanMutation();

  useEffect(() => {
    const fetchdata = async () => {
      try {
        let result = await handleedit({ id, adminId });
        console.log(result);

        if (result.error) {
          console.log(result.error.data.error);
          toast.error(result.error.data.error, {
            position: toast.POSITION.TOP_CENTER,
          });
        }

        if (result.data) {
          let handleData = result.data.plandata;
          reset({ planname: handleData.planname, planmonth: handleData.planmonth, planinterest: handleData.planinterest });
        }
      } catch (error) {
        console.log(error);
      }
    };
    fetchdata();
  }, [id]);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
    mode: 'all',
  });

  const onSubmit = async (data) => {
    const response = await handleupdate({ data, adminId, planid: id });

    try {
      if (response.error) {
        toast.error(response.error.data.message);
      } else {
        toast.success(response.data.message, {
          position: toast.POSITION.TOP_CENTER,
          autoClose: false,
        });

        setTimeout(() => {
          navigate('/dashboard');
        }, 2500);
      }
    } catch (error) {
      console.log(error.message);
    }
  };

  return (
    <div className="bg-dark min-vh-100 d-flex flex-row align-items-center">
      <CContainer>
        <CRow className="justify-content-center">
          <CCol md={5}>
            <CCardGroup>
              <CCard className="p-4" style={{ backgroundColor: 'black' }}>
                <CCardBody>
                  <form onSubmit={handleSubmit(onSubmit)}>
                    <h2 className="text-primary">
                      Update Staking Plan <MdOutlinePublishedWithChanges />
                    </h2>
                    <p className="text-primary input-group-text">Staking details</p>
                    <div className="form-row">
                      <div className="form-group col">
                        <label className="fs-5">Plan Name</label>
                        <div className="input-group">
                          <input
                            name="planname"
                            type="text"
                            className={`form-control ${errors.planname ? 'is-invalid' : ''}`}
                            {...register('planname')}
                            placeholder="Enter plan name"
                          />
                          <span className="input-group-text rounded-end-3">
                            <MdOutlineDriveFileRenameOutline />
                          </span>
                          <div className="invalid-feedback">{errors?.planname?.message}</div>
                        </div>
                      </div>
                    </div>

                    <label className="fs-5">Month</label>
                    <div className="input-group">
                    <select
                        name="planmonth"
                        className={`form-control ${errors.planmonth ? 'is-invalid' : ''}`}
                        {...register('planmonth')}
                      >
                        <option value="">Select Month</option>
                        <option value="1">1 months</option>
                        <option value="2">2 months</option>
                        <option value="3">3 months</option>
                        <option value="4">4 months</option>
                        <option value="5">5 months</option>
                        <option value="6">6 months</option>
                        <option value="7">7 months</option>
                        <option value="8">8 months</option>
                        <option value="9">9 months</option>
                        <option value="10">10 months</option>
                        <option value="11">11 months</option>
                        <option value="12">12 months</option>
                      </select>
                      <span className="input-group-text rounded-end-3">
                        <MdCalendarMonth />
                      </span>
                      <div className="invalid-feedback">{errors?.planmonth?.message}</div>
                    </div>

                    <label className="fs-5">Interest</label>
                    <div className="input-group">
                      <input
                        name="planinterest"
                        type="text"
                        className={`form-control ${errors.planinterest ? 'is-invalid' : ''}`}
                        {...register('planinterest')}
                        placeholder="Enter interest"
                      />
                      <span className="input-group-text rounded-end-3">
                        <AiOutlinePercentage />
                      </span>
                      <div className="invalid-feedback">{errors?.planinterest?.message}</div>
                    </div>

                    <div className="form-group d-grid mt-4">
                      <button type="submit" className="btn btn-primary mr-1">
                        Approve <BiRightArrowAlt />
                      </button>
                    </div>
                  </form>
                </CCardBody>
              </CCard>
            </CCardGroup>
          </CCol>

          <CCol md={4}>
            {/* Add your image here */}
            <img src={stakingListImage} alt="Staking List" style={{ width: '100%', height: '100%' }} />
          </CCol>

          <ToastContainer />
        </CRow>
      </CContainer>
    </div>
  );
};

export default UpdatestakingPlan;