import React, { useEffect, useRef, useState } from 'react'
import { CButton, CCard, CCardBody, CCardFooter, CCardHeader, CCol, CRow } from '@coreui/react'
import { CKEditor } from '@ckeditor/ckeditor5-react';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { toast, ToastContainer } from 'react-toastify'
import { useNavigate } from 'react-router-dom';
import { useDeleteFaqQueryDataMutation, useGetAllFaqQueryMutation, useGetSingleFaqQueryDataMutation, useHandleCreateFAQMutation } from '../../../redux/services/adminAPI';
import 'react-toastify/dist/ReactToastify.css';

const FAQPage = () => {

  const navigate = useNavigate()
  const inputRef = useRef(null)
  // RTK Query
  const [ckData, setCKData] = useState(null);
  const [allFaqData, setAllFaqData] = useState([]);

  // rtK qUERY
  const [createFaq] = useHandleCreateFAQMutation()
  const [getSingleData] = useGetSingleFaqQueryDataMutation()
  const [getAllFaqDatas] = useGetAllFaqQueryMutation()
  const [deleteFaqQuery] = useDeleteFaqQueryDataMutation()

  const [questions, setQuestions] = useState('')
  const [faqQueryId, setFaqQueryId] = useState(null)

  useEffect(() => {
    const fetchingAllFaqData = async () => {
      const response = await getAllFaqDatas()
      if (response.error) {
        return toast.error('Data Fetching Error', {
          position: toast.POSITION.TOP_CENTER
        })
      }
      const allDatas = response.data.getfaqDatas
      setAllFaqData(allDatas)
    }
    fetchingAllFaqData()
  }, [])


  const handleEditorChange = (event, editor) => {
    const data = editor.getData();
    setCKData(data); // Set the CKEditor data

  };

  const handleSumbit = async (e) => {
    e.preventDefault();
    if (questions.length <= 10) {
      return toast.error('Please Given Atleast 10 Characters Question', {
        position: toast.POSITION.TOP_CENTER
      })
    }

    if (ckData === null) {
      return toast.error('Please Fill Answer Sections', {
        position: toast.POSITION.TOP_CENTER
      })
    }

    if (ckData.length <= 20) {
      return toast.error('Please Given Atleast 10 Characters Answer', {
        position: toast.POSITION.TOP_CENTER
      })
    }
    try {
      const response = await createFaq({ questions, answers: ckData, id: faqQueryId })
      if (response.error) {
        return toast.error(response.error.data.message, {
          position: toast.POSITION.TOP_CENTER
        })
      }
      toast.success(response.data.message, {
        position: toast.POSITION.TOP_CENTER
      })
      setTimeout(()=>{
        navigate('/dashBoard')
      },5000)
    
    } catch (err) {
      console.log(err.message)
    }
  };

  const handleUpdateFaqQuery = async (id) => {
    try {
      const response = await getSingleData({ id })
      if (response.error) {
        return toast.error('Data Fetching Data')
      }
      setFaqQueryId(id)
      const faqData = response.data.getFaqSingleData
      setQuestions(faqData.questions)
      setCKData(faqData.answers)

    } catch (error) {
      console.log(error.message);
    }
  }


  const faqQueryDeleteData = async (id) => {
    try {
      const deleteReponse = await deleteFaqQuery({ id })
      if (deleteReponse.error) {
        return toast.error('Delete Data Error', {
          position: toast.POSITION.TOP_CENTER
        })
      }
      window.scrollTo({ top: 0, left: 0, behavior: 'smooth' });
      // inputRef.current.focus()
      toast.success(deleteReponse.data.message, {
        position: toast.POSITION.TOP_CENTER
      })
      setTimeout(()=>{
        navigate('/dashboard')
      },2000)
    
    } catch (error) {
      console.log(error.message);

    }
  }

  return (

    <>
      <CRow className="justify-content-center">
        <CCol xs={12} md={8} lg={6}>
          <CCard className="mb-4" style={{ backgroundColor: 'black' }}>
            <CCardHeader>
              <h2 className='text-center text-white'>FAQ UPDATES</h2>
            </CCardHeader>
            <CCardBody>
              <form onSubmit={handleSumbit}>
                <div className="mb-3">
                <ToastContainer />
                  <div className="mb-3">
                    <label className='form-label fw-bold h4 text-white' htmlFor="faq">Questions :</label>
                    <input type="text"
                      name="faq"
                      ref={inputRef}
                      id="faq"
                      defaultValue={questions}
                      className='form-control mb-3'
                      onChange={(e) => setQuestions(e.target.value)}
                    />
                  </div>

                  <div>
                    <label className='form-label fw-bold h4 mb-2 text-white' htmlFor="faq">Answers :</label>
                    <CKEditor
                      editor={ClassicEditor}
                      style={{ height: '200px', color: 'black' }}
                      onChange={handleEditorChange}
                      data={ckData === null ? '' : ckData}
                    />
                  </div>
                </div>
                <div className='d-grid'>
                  <button className='btn btn-success' type="submit">Submit </button>
                </div>
              </form>
            </CCardBody>
          </CCard>
        </CCol>
      </CRow>


      {allFaqData.length > 0 && (
      <>
          <h3 className="mb-3 text-center">ADD FAQs:</h3>
         {allFaqData.map((faqData) => (
           
            <CCard key={faqData._id} className="mb-4" style={{ backgroundColor: 'black', color: 'white' }}>
               <CCardHeader className="fw-bold">{faqData.questions} ?</CCardHeader>
              <CCardBody>
               <div dangerouslySetInnerHTML={{ __html: faqData.answers }} />
              </CCardBody>
              <CCardFooter>
                <div className="d-flex justify-content-between">
                  <button onClick={() => handleUpdateFaqQuery(faqData._id)} type="button" className="btn btn-primary">
                     EDIT
                  </button>
                 <button onClick={() => faqQueryDeleteData(faqData._id)} type="button" className="btn btn-danger">
                     DELETE
                  </button>
                 </div>
              </CCardFooter>
            </CCard>
            
      
          ))}
        </>
       )}
    </>
   );
 };

export default FAQPage