import React from 'react'
import DataTable from 'react-data-table-component';
import { useNavigate } from 'react-router-dom';
import { usePlanDataQuery } from '../../../redux/services/adminAPI';
import stakingListImage from '../../../assets/images/avatars/stack.jpg'; 


    const Stakingplanlist = () => {
    const navigate = useNavigate();
    const { isLoading, data, isSuccess, isError } = usePlanDataQuery();
    
    const handleEdit = (id) => {
        navigate(`/UpdateStakingPlan/${id}`);
      
      };



      const columns = [
        {
          id: 1,
          name: "S.NO",
          selector: (row, index) => index + 1,
          reorder: true
        },
        {
          id: 2,
          name: "PLAN NAME",
          selector: (row) => row.planname,
          sortable: true,
          reorder: true
        },
        {
          id: 3,
          name: "MONTHS",
          selector: (row) => `${row.planmonth} months`,
          sortable: true,
          reorder: true
        },
        {
          id: 4,
          name: "INTEREST %",
          selector: (row) => `${row.planinterest} %`,
          sortable: true,
          reorder: true
        },
        {
            id: 5,
            name: 'EDIT',
            cell: (row) => (
              <button className='btn btn-warning' onClick={()=>{handleEdit(row._id)}}>
                Edit
              </button>
            ),
            allowOverflow: true,
            button: true,
          },
        
      ];
    


  
    let handleData;
    if (isLoading) {
      handleData = <p>Loading...</p>;
    }
    if (isError) {
      handleData = <p>There is an error in staking plan list</p>;
    }
  
    if (isSuccess) {
      handleData = (
        <DataTable
        title={
          <div className="d-flex align-items-center">
            <img src={stakingListImage} alt="Buyer List" style={{ marginRight: '10px', width:'50%' }} />
         STACKING_PLAN_LIST
          </div>
        }
          columns={columns}
          data={data.getAllplan}
          defaultSortFieldId={1}
          pagination
        />
      );
    }
    
    return (
      <div
      className="container-fluid d-flex justify-content-center align-items-center"
      style={{ minHeight: '100vh', backgroundColor: 'black', color: 'white' }}
    >
      <div className="row">
        <div className="col-md-12 table table-primary table-striped">{handleData}</div>
      </div>
    </div>
    );
  };
  
  export default Stakingplanlist;