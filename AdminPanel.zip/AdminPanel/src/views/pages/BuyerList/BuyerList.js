import React from 'react';
import DataTable from 'react-data-table-component';
import { useNavigate } from 'react-router-dom';
import { useBuyplanDataQuery } from '../../../redux/services/adminAPI';
import buyerListImage from '../../../assets/images/avatars/buyerlist.webp';


const Stakingplanlist = () => {
  const navigate = useNavigate();
  const { isLoading, data, isSuccess, isError } = useBuyplanDataQuery();

  const columns = [
    {
      id: 1,
      name: 'S.NO',
      selector: (row, index) => index + 1,
      reorder: true,
    },
    {
      id: 2,
      name: 'PLAN NAME',
      selector: (row) => row.planname,
      sortable: true,
      reorder: true,
    },
    {
      id: 3,
      name: 'AMOUNT',
      selector: (row) => `${row.planamount} amount`,
      sortable: true,
      reorder: true,
    },
    {
      id: 4,
      name: 'INTEREST %',
      selector: (row) => `${row.amountinterest} %`,
      sortable: true,
      reorder: true,
    },
  ];

  let handleData;
  if (isLoading) {
    handleData = <p>Loading...</p>;
  }
  if (isError) {
    handleData = <p>There is an error in staking plan list</p>;
  }

  if (isSuccess) {
    handleData = (
      <DataTable
      title={
        <div className="d-flex align-items-center">
          <img src={buyerListImage} alt="Buyer List" style={{ marginRight: '10px', width:'50%' }} />
          BUYER_LIST
        </div>
      }
        columns={columns}
        data={data.getAllbuyplan}
        defaultSortFieldId={1}
        pagination
      />
    );
  }

  return (
    <div
      className="container-fluid d-flex justify-content-center align-items-center"
      style={{ minHeight: '100vh', backgroundColor: 'black', color: 'white' }}
    >
      <div className="row">
        <div className="col-md-12 table table-primary table-striped">{handleData}</div>
      </div>
    </div>
  );
};

export default Stakingplanlist;