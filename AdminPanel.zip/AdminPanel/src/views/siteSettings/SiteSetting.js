import React from "react";
import { useNavigate } from "react-router-dom";
import { useGetContentQuery } from "../../redux/services/adminAPI";

const SiteSetting = () => {
  const navigate = useNavigate();
  const { data, isLoading, isError } = useGetContentQuery();
  const contents = data?.data;

  if (isLoading) {
    return <h1>Loading...</h1>;
  }
  if (isError) {
    return <div>Error...</div>
}


  return (
    <>
      <div className="d-flex justify-content-center align-items-center" >
        {/* <h3>CONTENT ADD </h3> */}
        <button
          className="btn btn-primary " style={{marginRight:'100px'}}
          onClick={() => navigate("/addcontent")}
        >
          Add Content
        </button>
      </div>
      <div className="mt-5" style={{ backgroundColor: 'black', color: 'white' }}>
        {/* <h2 style={{textAlign:'center'}}>TABLES</h2> */}
        <table className="table"  style={{ backgroundColor: 'black', color: 'white' }}>
          <thead style={{ backgroundColor: 'black', color: 'white' }}>
              <tr  style={{ backgroundColor: 'black', color: 'white' }}>
              <th scope="col"  style={{ backgroundColor: 'black', color: 'white' }}>S.No</th>
              {/* <th scope="col"  style={{ backgroundColor: 'black', color: 'white' }}> ID CONTENT</th> */}
              <th scope="col"  style={{ backgroundColor: 'black', color: 'white' }}>CONTENT</th>
              <th scope="col"  style={{ backgroundColor: 'black', color: 'white' }}>DATA</th>
              <th scope="col "  style={{ backgroundColor: 'black', color: 'white' }}>ACTION</th>
            </tr>
          </thead>
          <tbody>
            {contents?.map((content, index) => (
              <tr key={content?._id} >
                <td className="serial-no py-3"  style={{ backgroundColor: 'black', color: 'white' }}>{index + 1}</td>
                {/* <td className="serial-no py-3"  style={{ backgroundColor: 'black', color: 'white' }}>{content?._id}</td> */}
                <td className="py-3"  style={{ backgroundColor: 'black', color: 'white' }}>{content?.content}</td>
                <td
                  className="py-3"  style={{ backgroundColor: 'black', color: 'white' }}
                  dangerouslySetInnerHTML={{ __html: content?.editorData }}
                />
                <td  style={{ backgroundColor: 'black', color: 'white' }}>
                  <button
                    className="btn btn-primary" 
                    onClick={() => navigate(`/ckeditor/${content?._id}`)}
                  >
                    Edit
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
};

export default SiteSetting;