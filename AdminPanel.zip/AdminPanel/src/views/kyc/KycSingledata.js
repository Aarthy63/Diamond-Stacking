
// import React, { useEffect, useState } from 'react'
// import { useParams } from 'react-router-dom';
// import { useNavigate } from 'react-router-dom';
// import { useForm } from 'react-hook-form';
// import { yupResolver } from '@hookform/resolvers/yup';
// import * as Yup from 'yup';
// import Swal from 'sweetalert2';
// import { useGetKycDataQuery, useApproveKycMutation, useRejectKycMutation,  } from '../../redux/services/adminAPI';
// import { Button, Modal, ModalBody, ModalFooter } from "reactstrap";
// //import { useGetSingleUserQuery } from '../../redux/services/adminAPI';
// import Card from 'react-bootstrap/Card';

// const schema = Yup.object().shape({
//     message: Yup.string().required('message is required').min(3, 'Enter atleast 3 characters').trim(),
// });

// const KycSingleData = () => {

//     const [modal, setModal] = useState(false);
//     const [message, setMessage] = useState("");
//     const { id } = useParams();
//     console.log(id);
//     const [ApproveKyc] = useApproveKycMutation()
//     const [RejectKyc] = useRejectKycMutation()
//     const { register, handleSubmit, formState: { errors }, reset } = useForm({
//         resolver: yupResolver(schema),
//         mode: 'all'
//     });
//     const { data, isLoading } = useGetKycDataQuery( id)
//     const singleKycData = data?.SingleKyc

//     if (isLoading) {
//         return <div>Loading...</div>
//     }
//     const toggle = () => {
//         setModal(!modal);
//         setMessage("");
//     };

//     const onSubmit = async () => {
//         const approveResponse = await ApproveKyc({ id: id })
//         // if (approveResponse.error) {
//         //     return Swal.fire({
//         //         icon: "error",
//         //         title: "Oops...",
//         //         text: approveResponse.error.data.message,
//         //     })
//         // }
//         Swal.fire({
//             position: "top-end",
//             icon: "success",
//             title: `Kyc Approved`,
//             showConfirmButton: false,
//             timer: 2500
//         });
//     }

//     const handleVerify = async (data) => {
//         const Reason = data.message
//         const rejectResponse = await RejectKyc({ id, Reason })
//         Swal.fire({
//             position: "top-end",
//             icon: "success",
//             title: `Kyc Rejected`,
//             showConfirmButton: false,
//             timer: 2500
//         });
//         setModal(false);
//     }

//     return (
//         <div style={{backgroundColor:'black'}}>
//             <h5 className='text-danger text-center'>{singleKycData?.username} Details</h5>
//             <Card style={{ width: '18rem', backgroundColor:'black', color:'white', justifyContent:'center', alignItems:'center' }}>
//             <Card.Body>
//             <Card.Title> <h3 className="card-title text-center"> {singleKycData?.aadharName}</h3><br />
//                 <h6 className="card-title text-center">userName: {singleKycData?.username}</h6><br />
//                 <h6 className="card-text text-center">email: {singleKycData?.email}</h6><br /></Card.Title>
//                 <Card.Img variant="top" src={`http://localhost:8080/${singleKycData?.frontSideImg}`} />
//                 <Card.Img variant="top" src={`http://localhost:8080/${singleKycData?.backSideImg}`} />
//                 <Card.Img variant="top" src={`http://localhost:8080/${singleKycData?.kycSelfieImg}`} />                   
//                     <center><button className='btn btn-info' onClick={() => onSubmit()}>Approve</button><span>  </span>
//                     <button className='btn btn-warning' onClick={() => toggle()}>Reject</button></center>
//                     </Card.Body>
//                 </Card>
//             <Modal isOpen={modal} toggle={toggle} modalClassName="CmmnMdl" className="modal-md " style={{backgroundColor:'black'}}>
//                 <form onSubmit={handleSubmit(handleVerify)}>
//                     <ModalBody style={{backgroundColor:'black'}}>
//                         <div className="MdlHdr BrdBttm pb-3 mb-1 ">
//                             <div className="StkMdlHdd ">
//                                 <h4 className="text-white" style={{textAlign:"center"}}>
//                                   Enter Rejection Reason
//                                 </h4>
//                             </div>
//                         </div>
//                         <div className="modal-body">
//                             <input type='text' className={`form-control  ${errors?.message ? 'is-invalid' : ''
//                                 }`}
//                                 placeholder='Enter Reason' {...register("message")} name='message' />
//                             <div className="invalid-feedback ">
//                                 <span style={{ margin: "13px" }}>{errors?.message?.message}</span>
//                             </div>
//                         </div>
//                         <Button className="btn btn-primry" style={{marginLeft:'180px'}}>
//                             Verify
//                         </Button>
//                     </ModalBody>
                  
                        
                  
//                 </form>
//             </Modal>
//         </div >
//     )
// }

// export default KycSingleData

import React, { useEffect, useState } from "react";
import {
  useGetUserByIdQuery,
  useKycUpdateMutation,
} from "../../redux/services/adminAPI";
import { useParams, useNavigate } from "react-router-dom";
import { CKEditor } from "@ckeditor/ckeditor5-react";
import ClassicEditor from "@ckeditor/ckeditor5-build-classic";
import Swal from "sweetalert2";

const KycDetail = () => {

  const [frontsideStatus, setFrontsideStatus] = useState(null);
  const [backsideStatus, setBacksideStatus] = useState(null);
  const [showFrontsideButtons, setShowFrontsideButtons] = useState(true);
  const [showBacksideButtons, setShowBacksideButtons] = useState(true);
  const [content, setContent] = useState(null);

  const [isEditorEmpty, setIsEditorEmpty] = useState(true);
  const params = useParams();
  const userID = params.id;
  const navigate = useNavigate();
  // console.log(userID);

  const { data, isLoading, isError } = useGetUserByIdQuery(userID);
  const userDetail = data?.data.kyc;
  // console.log(userDetail);


  const userKycStatus = userDetail?.isApproved;
  // console.log(userKycStatus);

  const [kycUpdate] = useKycUpdateMutation();

  // Ck editor Data
  const handleData = (event, editor) => {
    const data = editor.getData();
    setContent(data);
    setIsEditorEmpty(data.length === 0);
  };

  const handleApprove = (side) => {
    if (side === "front") {
      setFrontsideStatus("approved");
      setShowFrontsideButtons(false);
      document.getElementById("frontside-error").innerHTML = ""; // Clear error message
    } else {
      setBacksideStatus("approved");
      setShowBacksideButtons(false);
      document.getElementById("backside-error").innerHTML = ""; // Clear error message
    }
  };

  const handleDecline = (side) => {
    if (side === "front") {
      setFrontsideStatus("declined");
      setShowFrontsideButtons(false);
      document.getElementById("frontside-error").innerHTML = ""; // Clear error message
    } else {
      setBacksideStatus("declined");
      setShowBacksideButtons(false);
      document.getElementById("backside-error").innerHTML = ""; // Clear error message
    }
  };

  const getStatusColorClass = (status) => {
    switch (status) {
      case "approved":
        return "text-success";
      case "declined":
        return "text-danger";
      default:
        return "";
    }
  };

  const handleSubmit = async () => {
    // Check for frontside image status
    if (frontsideStatus !== "approved" && frontsideStatus !== "declined") {
      document.getElementById("frontside-error").innerHTML = "Action required";
      return;
    } else {
      document.getElementById("frontside-error").innerHTML = ""; // Clear error message
    }

    // Check for backside image status
    if (backsideStatus !== "approved" && backsideStatus !== "declined") {
      document.getElementById("backside-error").innerHTML = "Action required";
      return;
    } else {
      document.getElementById("backside-error").innerHTML = ""; // Clear error message
    }

    const approvalStatus = {
      frontSideStatus: frontsideStatus === "approved" ? "Approved" : "Declined",
      backSideStatus: backsideStatus === "approved" ? "Approved" : "Declined",
      editorData: content,
    };

    const res = await kycUpdate({ id: userID, formData: approvalStatus });
    console.log(res);
    if (res?.data) {
      Swal.fire({
        icon: "success",
        title: "KYC updated!",
        text: "KYC Updated successfully...!",
      }).then(() => {
        navigate("/users");
      });
    }

    console.log(approvalStatus);
  };


  return (
    <div className="container mt-5">
      {userDetail?.upload.frontProof !== undefined ? (
        <>
          {" "}
          <div className="card p-5">
            <div className="card-body">
              <h3 className="card-title">KycDetail</h3>
               {/* Status  */}
              <p className="card-text mt-3">
                <strong>KYC Status:</strong> {userKycStatus ? <span>Approved</span> : <span>Pending</span>}
              </p>

              {/* Username */}
              {/* <p className="card-text">
                <strong>Username:</strong> {userDetail?.username}
              </p> */}

              {/* Mobile */}
              <p className="card-text">
                <strong>Mobile:</strong> {userDetail?.mobile}
              </p>

              {/* Address */}
              <p className="card-text">
                <strong>Address:</strong> {userDetail?.address}
              </p>

                    {/* Account */}
                    <p className="card-text">
                <strong>Account No:</strong> {userDetail?.accountNo}
              </p>

              {/* User's Last Update */}
              <p className="card-text">
                <strong className="me-2">Users Last Update:</strong> <span>
                          {" "}
                          {new Date(userDetail?.userLastUpdate).toLocaleDateString()}
                        </span>
                        <span>
                          {" "}
                          {new Date(userDetail?.userLastUpdate).toLocaleTimeString()}
                        </span>
              </p>

              <div className="row">
                {/* Frontside Image */}
                <div className="col-md-6">
                  <img
                    src={`http://localhost:8081/${userDetail?.upload.frontProof}`}
                    alt="Frontside Image"
                    className="img-fluid"
                    style={{ width: "200px", height: "200px" }}
                  />
                
                  <div className="mt-2">
                    {showFrontsideButtons && !userKycStatus && (
                      <>
                        <button
                          type="button"
                          className="btn btn-success me-2"
                          onClick={() => handleApprove("front")}
                        
                        >
                          Approve
                        </button>
                        <button
                          type="button"
                          className="btn btn-danger"
                          onClick={() => handleDecline("front")}
                         
                        >
                          Decline
                        </button>
                      </>
                    )}
                    {!showFrontsideButtons && (
                      <p className={getStatusColorClass(frontsideStatus)}>
                        Frontside:{" "}
                        {frontsideStatus === "approved"
                          ? "Approved"
                          : "Declined"}
                      </p>
                    )}
                    <p id="frontside-error" className="text-danger"></p>
                  </div>
                </div>

                {/* Backside Image */}
                <div className="col-md-6">
                  <img
                    src={`http://localhost:8081/${userDetail?.upload.backProof}`}
                    alt="Backside Image"
                    className="img-fluid"
                    style={{ width: "200px", height: "200px" }}
                  />
              
                  <div className="mt-2">
                    {showBacksideButtons && !userKycStatus && (
                      <>
                        <button
                          type="button"
                          className="btn btn-success me-2"
                          onClick={() => handleApprove("back")}
                        >
                          Approve
                        </button>
                        <button
                          type="button"
                          className="btn btn-danger"
                          onClick={() => handleDecline("back")}
                        >
                          Decline
                        </button>
                      </>
                    )}
                    {!showBacksideButtons && (
                      <p className={getStatusColorClass(backsideStatus)}>
                        Backside:{" "}
                        {backsideStatus === "approved"
                          ? "Approved"
                          : "Declined"}
                      </p>
                    )}
                    <p id="backside-error" className="text-danger"></p>
                  </div>
                </div>
              </div>
            </div>
            <div className="mt-3">
              {!userKycStatus ? (
                <>
                  {" "}
                  <label className="mb-2">Comments:</label>
                  <CKEditor
                    editor={ClassicEditor}
                    style={{ height: "200px" }}
                    onChange={handleData}
                  />{" "}
                </>
              ) : (
                <></>
              )}
            </div>

            <div className="card-footer bg-white">
              {/* Submit Button */}
              {!userKycStatus ? (
                <button
                  type="button"
                  className="btn btn-primary btn-lg mt-4"
                  onClick={handleSubmit}
                >
                  Submit
                </button>
              ) : (
                <></>
              )}
            </div>
          </div>
        </>
      ) : (
        <>
          <div>
            <h3>KYC Details Not Uploaded Yet!</h3>
          </div>
        </>
      )}
    </div>
  );
};

export default KycDetail;

