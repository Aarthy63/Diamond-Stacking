import React from 'react'
import { useGetUsersQuery } from '../../redux/services/adminAPI'
import DataTable from 'react-data-table-component'
import { useNavigate } from 'react-router-dom'

const RegisterList = () => {
    const navigate = useNavigate();
    const { data, isLoading, isError } = useGetUsersQuery()
    console.log(data);
    const userslist = data?.data ? data?.data : []
    console.log(userslist);
    if (isLoading) {
        return <div>Loading...</div>
    }
    if (isError) {
        return <div>Error...</div>
    }

    const columns = [
        {
            name: "S.No",
            cell: (row, index) => index + 1,
        },
        {
            name: "UserName",
            selector: "username",
            sortable: true,
        },
        {
            name: "Email",
            selector: "email",
            sortable: true,
        },
        {
            name: "Actions/View",
            cell: (row) => (
                row._id ?
                <button
                    className="btn btn-info"
                    onClick={() => navigate(`/KycSingleData/${row._id}`)}
                >
                    View
                </button> : <></>
            ),
        },
    ];
    return (
        <div>
            {/* <h1>Register List</h1> */}
            <DataTable
                columns={columns}
                data={userslist}
                pagination
                paginationPerPage={10}
                paginationRowsPerPageOptions={[10, 20, 30]}
            />
        </div>
    )
}

export default RegisterList
