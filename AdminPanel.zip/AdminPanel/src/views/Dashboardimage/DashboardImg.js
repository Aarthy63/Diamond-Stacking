import React from 'react';
import dashboard from '../../assets/images/avatars/preview.gif';
import {
  CAvatar,
  CButton,
  CButtonGroup,
  CCard,
  CCardBody,
  CCardFooter,
  CCardHeader,
  CCol,
  CProgress,
  CRow,
  CTable,
  CTableBody,
  CTableDataCell,
  CTableHead,
  CTableHeaderCell,
  CTableRow,
} from '@coreui/react'

const DashboardImg = () => {
  return (
    <div> <CCol md={12}>
    <img src={dashboard} alt="Staking List" style={{ width: '100%', height: '100%' }} />
  </CCol>
  </div>
  )
}

export default DashboardImg